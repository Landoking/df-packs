#version 330
#extension GL_ARB_separate_shader_objects : require

// Vanilla 26.3 text.vsh + the Backrooms HUD (GUI text only).
// The plot sends the HUD as the action bar text every 2 ticks (DF func.HudUpdate). Negative spaces make the whole
// text 0 wide, so its origin is known: x = half the GUI width (integer), y = GUI height - 72 (vanilla draws the action
// bar at height - 68, 4 px up). Every part starts at that origin; here each part is moved to its place on screen.
// Art: textures/hud/*.png via font backrooms:hud (tools/hud_art.mjs), shown 1 texture px = 1 GUI px (no mixels).
//
// 1) Bars: glyphs coloured with a marker, red 254, green = part, blue = fill in px:
//      1 sanity bottle back, 2 its liquid (cut at blue, wavy), 3 its glass + label        -> top right
//      4 stamina bar back, 5 its fill (cut at blue), 6 its notches, 7 "STAMINA"          -> right edge, standing up
//    text.fsh draws them in their own texture colours and cuts the fills.
// 2) Banners (level names, messages): text in fonts backrooms:banner0-3, the vanilla font pushed BANNER_OFF +
//    slot * BANNER_STEP px down. Any GUI text that far below the action bar is banner text of that slot (keeps its own
//    colour and shadow) and is moved to the banner rows near the top, centred. Each banner's background is one block
//    glyph marked green 8 (blue = half width / 2): stretched to that width, and text.fsh fades it black 0-75%-0.
// 3) Spectating (dead) HUD, the same way with more bands: 4 = party panel header (party0), 5-8 = party rows 1-4
//    (party1-4), left-aligned in the panel at the top left (under the bodycam's REC); 9 = the spectated player's name
//    with its arrows (spec), centred near the bottom. Player heads (<head:name>, drawn on the normal line) are marked
//    green 9, blue = their row, and moved into that row's face slot.

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;

#ifdef IS_GUI
layout(location = 4) out vec2 hudLocal;      // px inside the part (before standing it up)
layout(location = 5) flat out vec4 hudInfo;  // x: fill px (-1 = none), y: mode (0 off, 1 art, 2 banner bg), z: wavy
layout(location = 6) flat out vec4 hudTint;

const float ORIGIN_UP = 72.0;
const float MARGIN = 6.0;
const float BOTTLE_W = 64.0, BOTTLE_H = 16.0;
const float BAR_LEN = 82.0, BAR_H = 7.0, LABEL_H = 5.0, LABEL_GAP = 2.0;
const float BANNER_OFF = 200.0, BANNER_STEP = 40.0, BANDS = 10.0, BANNER_ROW = 17.0;
const float PANEL_X = 6.0, PANEL_Y = 28.0, PANEL_ROW = 16.0, SPEC_UP = 36.0, HEAD_TOP = 0.0;

// GUI y of a party panel band's text line: 4 = header, 5-8 = rows 1-4
float partyLine(float k) {
    return k < 4.5 ? PANEL_Y + 3.0 : PANEL_Y + 13.0 + (k - 5.0) * PANEL_ROW + 4.0;
}
#endif

void main() {
    vec4 pos = ModelViewMat * vec4(Position, 1.0);
    gl_Position = ProjMat * pos;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;

#ifdef IS_GUI
    hudLocal = vec2(0.0);
    hudInfo = vec4(-1.0, 0.0, 0.0, 0.0);
    hudTint = vec4(1.0);
    float guiW = floor(2.0 / abs(ProjMat[0][0]) + 0.5);
    float guiH = floor(2.0 / abs(ProjMat[1][1]) + 0.5);
    vec2 rel = pos.xy - vec2(floor(guiW * 0.5), guiH - ORIGIN_UP);
    ivec3 c = ivec3(round(Color.rgb * 255.0));
    bool marked = c.r == 254 && c.g >= 1 && c.g <= 9;
    bool banner = rel.y > BANNER_OFF - 10.0 && rel.y < BANNER_OFF + BANNER_STEP * BANDS;

    if (marked && c.g == 9) {
        // a player head for party row blue: into that row's face slot
        vec2 p = vec2(PANEL_X + 6.0 + rel.x, partyLine(4.0 + float(c.b)) + rel.y - HEAD_TOP);
        hudInfo.y = 1.0;
        gl_Position = ProjMat * vec4(p, pos.z, 1.0);
    } else if (banner) {
        float k = floor((rel.y - (BANNER_OFF - 10.0)) / BANNER_STEP);
        float ly = rel.y - (BANNER_OFF + BANNER_STEP * k);
        // banner slot k: rows from 20% down the screen; text keeps its colour, centred on the screen
        float top = floor(guiH * 0.2) + k * BANNER_ROW;
        vec2 p = vec2(floor(guiW * 0.5) + rel.x, top + ly);
        if (k > 3.5 && k < 8.5) {
            // party panel, top left
            p = vec2(PANEL_X + rel.x, partyLine(k) + ly);
        } else if (k > 8.5) {
            // spectated player's name, bottom centre
            p = vec2(floor(guiW * 0.5) + rel.x, guiH - SPEC_UP + ly);
        }
        if (marked && c.g == 8) {
            // background block: stretch to +-half width, faded in text.fsh
            float hw = float(c.b) * 2.0;
            float side = rel.x < 0.0 ? -1.0 : 1.0;
            p.x = floor(guiW * 0.5) + side * hw;
            hudLocal = vec2(side * hw, ly);
            hudInfo = vec4(hw, 2.0, 0.0, 0.0);
        }
        gl_Position = ProjMat * vec4(p, pos.z, 1.0);
    } else if (marked && c.g <= 7) {
        vec2 p;
        hudInfo.y = 1.0;
        if (c.g <= 3) {
            // sanity bottle, top right (glyph top is 7 - height above the line)
            vec2 l = vec2(rel.x, rel.y - (7.0 - BOTTLE_H));
            hudLocal = l;
            p = vec2(guiW - MARGIN - BOTTLE_W, MARGIN) + l;
            if (c.g == 2) hudInfo.xz = vec2(float(c.b), 1.0);
        } else {
            // stamina bar, standing on the right edge, centred: the bar's left end at the bottom
            float h = c.g == 7 ? LABEL_H : BAR_H;
            vec2 l = vec2(rel.x, rel.y - (7.0 - h));
            hudLocal = l;
            vec2 a = vec2(guiW - MARGIN - BAR_H, floor(guiH * 0.5 + BAR_LEN * 0.5));
            if (c.g == 7) {
                // "STAMINA" along its left side, reading upwards
                a.x -= LABEL_GAP + LABEL_H;
                a.y -= 3.0;
            }
            p = vec2(a.x + l.y, a.y - l.x);
            if (c.g == 5) hudInfo.x = float(c.b);
        }
        gl_Position = ProjMat * vec4(p, pos.z, 1.0);
    }
#endif
}
