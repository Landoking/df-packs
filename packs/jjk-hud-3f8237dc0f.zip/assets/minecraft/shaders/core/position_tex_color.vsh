#version 330
#extension GL_ARB_separate_shader_objects : require

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl and projection.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

layout(location = 0) in vec3 Position;
layout(location = 1) in vec2 UV0;
layout(location = 2) in vec4 Color;

layout(location = 0) out vec2 texCoord0;
layout(location = 1) out vec4 vertexColor;
layout(location = 2) out vec3 dollInfo;   // xy: pixel inside the paperdoll quad, z: 1 on the paperdoll

// JJK: recognise the inventory paperdoll quad and move it (startup shader: no #include possible)
vec3 jjkDoll(vec3 pos, out vec3 info) {
    info = vec3(0.0);
    if (ProjMat[3][3] < 0.99) return pos;
    float guiW = ceil(2.0 / ProjMat[0][0] - 0.01);
    float guiH = ceil(2.0 / abs(ProjMat[1][1]) - 0.01);
    vec2 lt = vec2(floor((guiW - 176.0) * 0.5), floor((guiH - 166.0) * 0.5));
    vec2 a = lt + vec2(26.0, 8.0), b = a + vec2(49.0, 70.0);
    bool ax = abs(pos.x - a.x) < 0.01, bx = abs(pos.x - b.x) < 0.01;
    bool ay = abs(pos.y - a.y) < 0.01, by = abs(pos.y - b.y) < 0.01;
    if ((ax || bx) && (ay || by)) {
        info = vec3(bx ? 49.0 : 0.0, by ? 70.0 : 0.0, 1.0);
        pos.xy += vec2(-79.0, 78.0);
    }
    return pos;
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(jjkDoll(Position, dollInfo), 1.0);

    texCoord0 = UV0;
    vertexColor = Color;
}
