#version 330
#extension GL_ARB_separate_shader_objects : require

// Distance fog for generated levels (goes with the bodycam look): everything fades into FogColor between Start and
// End blocks away, and empty space (unloaded chunks, the void past the level) is pure fog, so you never see where
// the level ends. Reads the depth buffer, so func.ApplyEffects runs it before the camera bob moves the picture.
// A little slow noise in the fog keeps it from looking like a flat wall. Variants: post_effect/fog_*.json.

#include <minecraft:globals.glsl>
#include <backrooms:sky_noise.glsl>

uniform sampler2D InSampler;
uniform sampler2D DepthSampler;

layout(location = 0) in vec2 texCoord;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(std140) uniform FogConfig {
    vec3 FogColor;
    float Start;
    float End;
    float Density;
};

layout(location = 0) out vec4 fragColor;

void main() {
    vec3 col = texture(InSampler, texCoord).rgb;
    float depth = texture(DepthSampler, texCoord).r;
    // perspective depth -> distance along the view ray (near plane 0.05; the far plane barely matters this close)
    float dist = depth >= 1.0 ? 1e6 : 0.05 / max(1.0 - depth, 1e-7);
    // distance from the centre of the screen grows towards the edges: use the real ray length so the fog is round
    vec2 ndc = texCoord * 2.0 - 1.0;
    dist *= length(vec3(ndc * vec2(OutSize.x / OutSize.y, 1.0) * 0.6, 1.0));
    float t = clamp((dist - Start) / max(End - Start, 0.001), 0.0, 1.0);
    float f = 1.0 - exp(-t * t * Density);
    f = depth >= 1.0 ? 1.0 : clamp(f / (1.0 - exp(-Density)), 0.0, 1.0);
    // slow drifting variation (screen space, very subtle)
    float s = GameTime * 1200.0;
    float n = vnoise(texCoord * vec2(3.0, 2.0) + vec2(s * 0.03, s * 0.017)) - 0.5;
    vec3 fog = FogColor * (1.0 + n * 0.12);
    fragColor = vec4(mix(col, fog, f), 1.0);
}
