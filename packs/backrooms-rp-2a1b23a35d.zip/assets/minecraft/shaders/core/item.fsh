#version 330
#extension GL_ARB_separate_shader_objects : require

// Vanilla 26.3 item.fsh + the Backrooms camera probe (see item.vsh). Probe pixels x = 0..7 on the bottom row hold:
// world -Z and world +Y as seen by the camera (view space, -1..1) and ProjMat[0][0] / 8, ProjMat[1][1] / 8,
// each as a 16-bit value in red (high byte) + green (low byte), with blue = 173 as a "probe present" check.

#ifdef GLINT
#include <minecraft:globals.glsl>
#endif
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>
#include <backrooms:marker_guard.glsl>

uniform sampler2D Sampler0;

#ifdef GLINT
uniform sampler2D GlintSampler;
#endif

#ifndef OIT_ALPHA_ONLY
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif
layout(location = 2) in vec4 vertexColor;
#ifndef OIT_ALPHA_ONLY
layout(location = 3) in vec4 lightMapColor;
layout(location = 4) in vec4 overlayColor;
#endif
layout(location = 5) in vec2 texCoord0;
#ifdef GLINT
layout(location = 6) in vec2 texCoordGlint;
#endif
layout(location = 7) in float probeFlag;
layout(location = 8) flat in vec3 probeRight;
layout(location = 9) flat in vec3 probeUp;
layout(location = 10) flat in vec2 probeProj;

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

#ifndef OIT_ALPHA_ONLY
vec4 calculateFinalColor(vec4 color) {
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
    color *= lightMapColor;

    #ifdef GLINT
    vec4 glintColor = GlintAlpha * texture(GlintSampler, texCoordGlint);// Glint color modulator?
    // Matches BlendFuntion.GLINT
    color.rgb += glintColor.rgb * glintColor.rgb;
    #endif

    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    return apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
}

vec4 probeEncode(float v01) {
    float u = floor(clamp(v01, 0.0, 1.0) * 65535.0 + 0.5);
    float hi = floor(u / 256.0);
    float lo = u - hi * 256.0;
    return vec4(hi / 255.0, lo / 255.0, 173.0 / 255.0, 1.0);
}
#endif

void main() {
    if (probeFlag > 0.5) {
        #if defined(OIT_ALPHA_ONLY) || defined(OIT_ACCUMULATE)
        discard;
        #else
        // pixels 0-2: quad A normal (world -Z in view space), 3: ProjMat[0][0] / 8
        // pixels 4-6: quad B normal (world +Y in view space), 7: ProjMat[1][1] / 8
        int i = int(gl_FragCoord.x);
        float v;
        int j = i % 4;
        if (j == 0) v = probeRight.x * 0.5 + 0.5;
        else if (j == 1) v = probeRight.y * 0.5 + 0.5;
        else if (j == 2) v = probeRight.z * 0.5 + 0.5;
        else v = (i < 4 ? probeProj.x : probeProj.y) / 8.0;
        fragColor = probeEncode(v);
        return;
        #endif
    }

    vec4 color = texture(Sampler0, texCoord0);
    // the sky-cube paper props are meant to be markers, everything else is guarded
    vec3 raw = color.rgb;
    bool skyProp = max(raw.r, max(raw.g, raw.b)) > 0.99 && (int(raw.r < 0.01) + int(raw.g < 0.01) + int(raw.b < 0.01)) == 2 && texture(Sampler0, texCoord0).a > 0.99;
    #ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
    #endif

    color *= vertexColor * ColorModulator;

    #ifdef GLINT
    color.a = max(color.a, GlintAlpha);
    #endif

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = skyProp ? calculateFinalColor(color) : backrooms_guard(calculateFinalColor(color));
    #endif
}
