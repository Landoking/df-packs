#version 330
#extension GL_ARB_separate_shader_objects : require

// Vanilla 26.3 item.vsh + the Backrooms camera probe.
// An item whose texture is the probe colour (254, 1, 253) is not drawn where it is: its quad is moved to the
// bottom-left 8x1 pixels of the screen and item.fsh writes the camera rotation + projection there, for the
// backrooms:skybox post effect to read (post passes get no camera matrices). Items go through vanilla shaders
// even with Sodium, so this works with or without it.

#include <minecraft:light.glsl>
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:sample_lightmap.glsl>
#include <minecraft:globals.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
layout(location = 3) in ivec2 UV1;
layout(location = 4) in ivec2 UV2;
#ifdef GLINT_SPECIAL
layout(location = 5) in vec2 UV3;
#endif
layout(location = 6) in vec3 Normal;

uniform sampler2D Sampler0;
#ifndef OIT_ALPHA_ONLY
uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif
layout(location = 2) out vec4 vertexColor;
#ifndef OIT_ALPHA_ONLY
layout(location = 3) out vec4 lightMapColor;
layout(location = 4) out vec4 overlayColor;
#endif

layout(location = 5) out vec2 texCoord0;
#ifdef GLINT
layout(location = 6) out vec2 texCoordGlint;
#endif
layout(location = 7) out float probeFlag;
layout(location = 8) flat out vec3 probeRight;
layout(location = 9) flat out vec3 probeUp;
layout(location = 10) flat out vec2 probeProj;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    #ifndef OIT_ALPHA_ONLY
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    #endif
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
    #ifndef OIT_ALPHA_ONLY
    lightMapColor = sample_lightmap(Sampler2, UV2);
    overlayColor = texelFetch(Sampler1, UV1, 0);
    #endif

    texCoord0 = UV0;
    #ifdef GLINT
    #ifdef GLINT_SPECIAL
    texCoordGlint = (TextureMat * vec4(UV3, 0.0, 1.0)).xy;
    #else
    texCoordGlint = (TextureMat * vec4(UV0, 0.0, 1.0)).xy;
    #endif
    #endif

    probeFlag = 0.0;
    probeRight = vec3(0.0);
    probeUp = vec3(0.0);
    probeProj = vec2(0.0);
    vec3 t = textureLod(Sampler0, UV0, 0.0).rgb * 255.0;
    if (abs(t.r - 254.0) < 0.5 && abs(t.b - 253.0) < 0.5 && (abs(t.g - 1.0) < 0.5 || abs(t.g - 2.0) < 0.5)) {
        // Quad A (green 1) is the probe's north face: its normal is world -Z as the camera sees it.
        // Quad B (green 2) is its top face: world +Y as the camera sees it. The probe never rotates.
        bool a = abs(t.g - 1.0) < 0.5;
        vec3 n = normalize(mat3(ModelViewMat) * Normal);
        probeFlag = a ? 1.0 : 2.0;
        probeRight = n;
        probeProj = vec2(ProjMat[0][0], ProjMat[1][1]);
        int c = gl_VertexIndex % 4;
        float x0 = a ? 0.0 : 4.0;
        vec2 px = vec2(x0 + ((c == 1 || c == 2) ? 4.0 : 0.0), (c >= 2) ? 1.0 : 0.0);
        // depth of a point just past the near plane, in whatever depth convention the projection uses
        // (26.3 may use reversed depth, where 0 is the far plane)
        vec4 nearClip = ProjMat * vec4(0.0, 0.0, -0.08, 1.0);
        gl_Position = vec4(px / ScreenSize * 2.0 - 1.0, nearClip.z / nearClip.w, 1.0);
    }
}