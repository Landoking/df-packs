#version 330
#extension GL_ARB_separate_shader_objects : require

// Bodycam bloom, step 1: keeps only the bright parts of the frame (sky windows, lit tiles, water glare).
// post_effect/bodycam.json blurs this and bodycam.fsh adds it back.

uniform sampler2D InSampler;

layout(location = 0) in vec2 texCoord;

layout(std140) uniform BrightConfig {
    float Threshold;
};

layout(location = 0) out vec4 fragColor;

void main() {
    vec3 c = texture(InSampler, texCoord).rgb;
    float l = max(c.r, max(c.g, c.b));
    fragColor = vec4(c * smoothstep(Threshold, 1.0, l), 1.0);
}
