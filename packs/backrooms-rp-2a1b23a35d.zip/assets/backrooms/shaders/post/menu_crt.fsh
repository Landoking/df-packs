#version 330
#extension GL_ARB_separate_shader_objects : require

// Menu screen look: slightly curved old monitor with scanlines, colour fringing, vignette, grain and flicker.
// Strengths live in post_effect/menu_crt.json (CrtConfig).

#include <minecraft:globals.glsl>
#include <backrooms:sky_noise.glsl>

uniform sampler2D InSampler;

layout(location = 0) in vec2 texCoord;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(std140) uniform CrtConfig {
    float Curve;
    float Scanlines;
    float Fringe;
    float Vignette;
    float Grain;
};

layout(location = 0) out vec4 fragColor;

void main() {
    vec2 cc = texCoord - 0.5;
    float r2 = dot(cc, cc);
    vec2 uv = 0.5 + cc * (1.0 + Curve * r2) / (1.0 + Curve * 0.5);
    if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) {
        fragColor = vec4(0.0, 0.0, 0.0, 1.0);
        return;
    }
    vec2 dir = normalize(cc + 1e-5) * Fringe * (0.4 + r2 * 4.0);
    vec3 col;
    col.r = texture(InSampler, uv + dir).r;
    col.g = texture(InSampler, uv).g;
    col.b = texture(InSampler, uv - dir).b;

    float t = GameTime * 1200.0;
    float lines = 0.5 + 0.5 * cos(uv.y * OutSize.y * 3.14159265 * 0.5);
    col *= 1.0 - Scanlines * lines;
    float roll = smoothstep(0.0, 0.02, abs(fract(uv.y * 0.6 - t * 0.12) - 0.5) - 0.47);
    col *= 1.0 + 0.04 * (1.0 - roll);
    col *= 1.0 - Vignette * r2 * 1.6;
    col *= 1.0 + 0.012 * sin(t * 47.0);
    col += (hash12(gl_FragCoord.xy + fract(t) * 917.0) - 0.5) * Grain;
    fragColor = vec4(col, 1.0);
}
