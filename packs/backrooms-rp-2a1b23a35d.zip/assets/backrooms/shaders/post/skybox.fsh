#version 330
#extension GL_ARB_separate_shader_objects : require

// Backrooms skybox blocks.
// The glazed terracotta models are flat, full-bright marker colours with two colour channels at exactly zero:
//   light blue -> (0, 0, B)  clouds      orange -> (R, 0, 0)  sunset      gray -> (0, G, 0)  midnight
// The test (backrooms_marker) tolerates fog; entities, items, text and particles can never pass it.
// Lighting only multiplies channels, so a zero channel stays zero under any light (vanilla or Sodium).
// This pass finds those pixels and paints the sky the camera would see through them: a real 3D skybox.
// The camera rotation + projection come from the camera probe (core/item.vsh writes them into the bottom-left
// 8 pixels). Without probe data it falls back to a flat screen-space sky.

#include <minecraft:globals.glsl>
#include <backrooms:sky_noise.glsl>
#include <backrooms:marker_guard.glsl>

uniform sampler2D InSampler;

layout(location = 0) in vec2 texCoord;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(location = 0) out vec4 fragColor;

const float TAU = 6.2831853;

vec2 drift(float r, float phase) {
    float a = GameTime * TAU + phase;
    return vec2(cos(a), sin(a)) * r;
}

float hash13(vec3 p) {
    p = fract(p * 0.1031);
    p += dot(p, p.zyx + 31.32);
    return fract((p.x + p.y) * p.z);
}

// ---------- probe ----------
float probeValue(int i, out bool ok) {
    vec4 c = texelFetch(InSampler, ivec2(i, 0), 0);
    ok = abs(c.b * 255.0 - 173.0) < 0.6;
    return (floor(c.r * 255.0 + 0.5) * 256.0 + floor(c.g * 255.0 + 0.5)) / 65535.0;
}

// Probe layout (core/item.fsh): pixels 0-2 = world -Z seen from the camera, 3 = ProjMat[0][0] / 8,
// pixels 4-6 = world +Y seen from the camera, 7 = ProjMat[1][1] / 8.
// Returns the camera's world axes as seen in view space: ex, ey, ez (rows of the world->view rotation).
bool readProbe(out vec3 ex, out vec3 ey, out vec3 ez, out vec2 proj) {
    bool a, b, c, d, e, f, g, h;
    vec3 negZ = vec3(probeValue(0, a), probeValue(1, b), probeValue(2, c)) * 2.0 - 1.0;
    ey = vec3(probeValue(4, e), probeValue(5, f), probeValue(6, g)) * 2.0 - 1.0;
    proj = vec2(probeValue(3, d), probeValue(7, h)) * 8.0;
    ez = normalize(-negZ);
    ey = normalize(ey);
    ex = normalize(cross(ey, ez));
    return a && b && c && d && e && f && g && h && proj.x > 0.05 && proj.y > 0.05;
}
// ---------- shared cloud helpers ----------
// clouds on a plane above (dir.y > 0) or a cloud sea below (dir.y < 0)
float cloudsAbove(vec3 d, vec2 off, float cover) {
    if (d.y <= 0.0) return 0.0;
    vec2 p = d.xz / (d.y + 0.12) * 0.9 + off;
    float n = fbm(p);
    float c = smoothstep(cover, cover + 0.25, n);
    return c * smoothstep(0.0, 0.18, d.y);
}

float cloudSea(vec3 d, vec2 off, out float shade) {
    shade = 0.0;
    if (d.y >= 0.02) return 0.0;
    float h = max(-d.y, 0.0) + 0.03;
    vec2 p = d.xz / h * 0.55 + off;
    float n = fbm(p);
    float n2 = fbm(p + vec2(0.35, 0.2));
    shade = clamp(0.55 + (n - n2) * 3.0, 0.0, 1.0);
    return smoothstep(0.28, 0.55, n);
}

// ---------- 3D skies ----------
vec3 sky3dClouds(vec3 d) {
    vec3 sun = normalize(vec3(0.45, 0.55, -0.70));
    float e = d.y;
    vec3 col = mix(vec3(0.70, 0.86, 1.00), vec3(0.17, 0.43, 0.93), smoothstep(-0.02, 0.75, e));
    float s = max(dot(d, sun), 0.0);
    col += vec3(1.0, 0.95, 0.85) * (0.35 * pow(s, 8.0) + 0.9 * pow(s, 400.0));
    for (int k = 0; k < 2; k++) {
        float fk = float(k);
        float c = cloudsAbove(d, drift(2.5 + fk, fk * 2.0) + vec2(fk * 13.1, 4.0), 0.50 + fk * 0.04);
        vec3 cc = mix(vec3(0.78, 0.84, 0.94), vec3(1.0), 0.6 + 0.4 * s);
        col = mix(col, cc, c * 0.85);
    }
    float shade;
    float sea = cloudSea(d, drift(1.5, 1.0), shade);
    vec3 seaCol = mix(vec3(0.62, 0.72, 0.88), vec3(1.0, 1.0, 0.98), shade);
    vec3 below = mix(vec3(0.55, 0.70, 0.92), seaCol, sea);
    col = mix(col, below, smoothstep(0.03, -0.03, e));
    col = mix(col, vec3(0.80, 0.90, 1.0), exp(-abs(e) * 18.0) * 0.55);
    return col;
}

vec3 sky3dSunset(vec3 d) {
    vec3 sun = normalize(vec3(-0.92, 0.07, 0.38));
    float e = d.y;
    float s = max(dot(d, sun), 0.0);
    vec3 col = mix(vec3(1.00, 0.62, 0.32), vec3(0.90, 0.38, 0.45), smoothstep(0.0, 0.30, e));
    col = mix(col, vec3(0.25, 0.17, 0.42), smoothstep(0.25, 0.95, e));
    col += vec3(1.0, 0.55, 0.22) * (0.55 * pow(s, 6.0));
    col = mix(col, vec3(1.0, 0.92, 0.70), smoothstep(0.9975, 0.9985, s));
    for (int k = 0; k < 2; k++) {
        float fk = float(k);
        vec3 ds = normalize(vec3(d.x, d.y * 2.2, d.z));
        float c = cloudsAbove(ds, drift(2.0 + fk, 3.0 + fk) + vec2(fk * 21.7, 1.0), 0.55);
        vec3 dark = vec3(0.33, 0.17, 0.35);
        vec3 lit = mix(vec3(1.0, 0.55, 0.50), vec3(1.0, 0.78, 0.52), s);
        col = mix(col, mix(dark, lit, 0.35 + 0.65 * pow(s, 2.0)), c * 0.85);
    }
    float shade;
    float sea = cloudSea(d, drift(1.2, 2.0), shade);
    vec3 seaCol = mix(vec3(0.42, 0.24, 0.40), mix(vec3(1.0, 0.62, 0.48), vec3(1.0, 0.82, 0.6), s), shade);
    vec3 below = mix(vec3(0.55, 0.30, 0.42), seaCol, sea);
    col = mix(col, below, smoothstep(0.03, -0.03, e));
    col = mix(col, vec3(1.0, 0.70, 0.45), exp(-abs(e) * 20.0) * 0.45);
    return col;
}

vec3 stars3d(vec3 d, float density) {
    vec3 g = d * density;
    vec3 cell = floor(g);
    float h = hash13(cell);
    if (h < 0.965) return vec3(0.0);
    vec3 pos = cell + 0.2 + 0.6 * vec3(hash13(cell + 1.7), hash13(cell + 5.3), hash13(cell + 9.1));
    float dist = length(g - pos);
    float tw = 0.65 + 0.35 * sin(GameTime * 1200.0 * (1.0 + h * 2.5) + h * TAU * 7.0);
    float b = smoothstep(0.22, 0.0, dist) * tw * (h - 0.965) / 0.035;
    return mix(vec3(0.75, 0.82, 1.0), vec3(1.0, 0.95, 0.85), hash13(cell + 3.1)) * b * 1.6;
}

vec3 sky3dMidnight(vec3 d) {
    vec3 moon = normalize(vec3(0.35, 0.42, -0.84));
    float e = d.y;
    vec3 col = mix(vec3(0.05, 0.08, 0.17), vec3(0.008, 0.012, 0.04), smoothstep(-0.05, 0.8, e));
    col += stars3d(d, 90.0) * smoothstep(-0.05, 0.15, e);
    col += stars3d(d, 180.0) * 0.6 * smoothstep(-0.05, 0.15, e);
    float m = dot(d, moon);
    col += vec3(0.55, 0.65, 0.95) * (0.20 * pow(max(m, 0.0), 30.0) + 0.3 * pow(max(m, 0.0), 600.0));
    float disc = smoothstep(0.9988, 0.9991, m);
    vec3 mt = normalize(cross(moon, vec3(0.0, 1.0, 0.0)));
    vec3 mb = cross(mt, moon);
    float crater = fbm(vec2(dot(d, mt), dot(d, mb)) * 900.0) * 0.35;
    col = mix(col, vec3(0.93, 0.94, 1.0) - crater * vec3(0.3, 0.28, 0.2), disc);
    float c = cloudsAbove(normalize(vec3(d.x, d.y * 1.8, d.z)), drift(2.0, 4.0), 0.58);
    col = mix(col, mix(vec3(0.03, 0.04, 0.09), vec3(0.20, 0.25, 0.40), 0.3 + 0.7 * pow(max(m, 0.0), 4.0)), c * 0.9);
    float shade;
    float sea = cloudSea(d, drift(1.0, 5.0), shade);
    vec3 seaCol = mix(vec3(0.03, 0.05, 0.10), vec3(0.20, 0.25, 0.38), shade * (0.4 + 0.6 * pow(max(m, 0.0), 2.0)));
    vec3 below = mix(vec3(0.02, 0.03, 0.07), seaCol, sea);
    col = mix(col, below, smoothstep(0.03, -0.03, e));
    col = mix(col, vec3(0.10, 0.14, 0.26), exp(-abs(e) * 20.0) * 0.4);
    return col;
}

// ---------- flat fallback (no probe) ----------
vec3 flatSky(int kind, vec2 uv, float aspect) {
    // map the screen to a fixed forward-looking direction so the 3D functions still give a sensible picture
    vec3 d = normalize(vec3((uv.x - 0.5) * aspect * 1.4, (uv.y - 0.45) * 1.4, -1.0));
    if (kind == 1) return sky3dClouds(d);
    if (kind == 2) return sky3dSunset(d);
    return sky3dMidnight(d);
}

void main() {
    ivec2 px = ivec2(gl_FragCoord.xy);
    vec4 c = texture(InSampler, texCoord);

    // hide the probe pixels
    if (px.y == 0 && px.x < 8) {
        bool ok;
        probeValue(px.x, ok);
        if (ok) {
            fragColor = vec4(texelFetch(InSampler, ivec2(px.x, 1), 0).rgb, 1.0);
            return;
        }
    }

    vec3 rgb = c.rgb;
    int kind = backrooms_marker(rgb);

    if (kind == 0) {
        fragColor = vec4(rgb, 1.0);
        return;
    }

    vec3 ex, ey, ez;
    vec2 proj;
    vec3 sky;
    if (readProbe(ex, ey, ez, proj)) {
        vec2 ndc = texCoord * 2.0 - 1.0;
        vec3 v = vec3(ndc.x / proj.x, ndc.y / proj.y, -1.0);
        vec3 d = normalize(vec3(dot(ex, v), dot(ey, v), dot(ez, v)));
        if (kind == 1) sky = sky3dClouds(d);
        else if (kind == 2) sky = sky3dSunset(d);
        else sky = sky3dMidnight(d);
    } else {
        sky = flatSky(kind, texCoord, OutSize.x / OutSize.y);
    }

    sky += (hash12(gl_FragCoord.xy) - 0.5) / 255.0;
    fragColor = vec4(sky, 1.0);
}
