#version 330
#extension GL_ARB_separate_shader_objects : require

// Handheld camera bob while walking/running: the frame sways side to side once per two steps, dips on every
// step and rolls a little, with a slow drift on top so it never looks mechanical. Strengths in BobConfig
// (post_effect/bob_walk.json, bob_run.json). DF picks idle / walk / run every few ticks while in a level (func.CameraBob).

#include <minecraft:globals.glsl>

uniform sampler2D InSampler;

layout(location = 0) in vec2 texCoord;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(std140) uniform BobConfig {
    vec2 Amp;
    float Steps;
    float Roll;
    float Zoom;
};

layout(location = 0) out vec4 fragColor;

const float TAU = 6.2831853;

void main() {
    float t = GameTime * 1200.0;
    float phase = t * Steps * 0.5 * TAU;
    float aspect = OutSize.x / OutSize.y;
    vec2 off = vec2(sin(phase) * Amp.x, (abs(cos(phase)) - 0.64) * Amp.y);
    off += vec2(sin(t * 0.7), sin(t * 0.53 + 1.3)) * Amp * 0.25;
    float r = sin(phase + 0.6) * Roll;
    vec2 p = (texCoord - 0.5) * vec2(aspect, 1.0);
    p = mat2(cos(r), -sin(r), sin(r), cos(r)) * p;
    vec2 uv = p / vec2(aspect, 1.0) + 0.5 + off;
    // fixed zoom (same in every variant, so switching idle/walk/run never pops) hides the moved frame's edge
    uv = 0.5 + (uv - 0.5) * (1.0 - Zoom);
    fragColor = vec4(texture(InSampler, uv).rgb, 1.0);
}
