#version 330
#extension GL_ARB_separate_shader_objects : require

// Found-footage VHS look for inside the levels (kept subtle): soft picture with sideways colour bleed, drifting
// chroma blotches, warm yellow grade with lifted blacks, slight fisheye + fringe + vignette, fine grain, a faint
// rolling tracking band, rare faint dropout dashes and a thin head-switching strip at the bottom.
// Strengths: post_effect/vhs.json (VhsConfig).

#include <minecraft:globals.glsl>
#include <backrooms:sky_noise.glsl>

uniform sampler2D InSampler;

layout(location = 0) in vec2 texCoord;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(std140) uniform VhsConfig {
    float Fisheye;
    float Fringe;
    float Smear;
    float Grade;
    float Grain;
    float Tracking;
    float Streaks;
    float Vignette;
};

layout(location = 0) out vec4 fragColor;

vec3 toYiq(vec3 c) {
    return vec3(dot(c, vec3(0.299, 0.587, 0.114)), dot(c, vec3(0.596, -0.274, -0.322)), dot(c, vec3(0.211, -0.523, 0.312)));
}

vec3 fromYiq(vec3 y) {
    return vec3(y.x + 0.956 * y.y + 0.621 * y.z, y.x - 0.272 * y.y - 0.647 * y.z, y.x - 1.106 * y.y + 1.703 * y.z);
}

void main() {
    float t = GameTime * 1200.0;
    vec2 px = 1.0 / OutSize;

    // lens: slight fisheye, zoomed so the corners stay inside the frame
    vec2 cc = texCoord - 0.5;
    float r2 = dot(cc, cc);
    vec2 uv = 0.5 + cc * (1.0 - Fisheye * 0.5 + Fisheye * r2) * 0.985;

    // tape: tiny per-line jitter, a faint rolling tracking band, a thin head-switching strip at the bottom
    float line = floor(uv.y * OutSize.y * 0.5);
    uv.x += (hash12(vec2(line, floor(t * 30.0))) - 0.5) * 1.2 * px.x;
    float bandY = 1.0 - fract(t * 0.045);
    float band = smoothstep(0.03, 0.0, abs(uv.y - bandY)) * Tracking;
    uv.x += (vnoise(vec2(uv.y * 160.0, t * 40.0)) - 0.5) * 0.006 * band;
    float head = smoothstep(0.018, 0.0, uv.y);
    uv.x += head * (0.006 + 0.004 * sin(t * 13.0 + uv.y * 300.0));
    uv = clamp(uv, px, 1.0 - px);

    // signal: soft luma, smeared chroma (colour bleeds sideways like composite video)
    vec3 sharp = texture(InSampler, uv).rgb;
    vec3 blur = (texture(InSampler, uv + vec2(px.x * 1.5, 0.0)).rgb + texture(InSampler, uv - vec2(px.x * 1.5, 0.0)).rgb
        + texture(InSampler, uv + vec2(0.0, px.y * 1.2)).rgb + texture(InSampler, uv - vec2(0.0, px.y * 1.2)).rgb) * 0.25;
    vec3 soft = mix(sharp, blur, 0.55);
    vec3 wide = vec3(0.0);
    for (int i = -3; i <= 3; i++) {
        wide += texture(InSampler, uv + vec2(float(i) * Smear * px.x * 2.0, 0.0)).rgb;
    }
    wide /= 7.0;
    vec3 yiq = vec3(toYiq(soft).x, toYiq(wide).yz);
    // drifting chroma blotches (tape colour noise)
    vec2 bp = uv * vec2(5.0, 9.0) + vec2(t * 0.15, t * 0.37);
    yiq.y += (vnoise(bp) - 0.5) * 0.035 * Grade;
    yiq.z += (vnoise(bp + 31.7) - 0.5) * 0.035 * Grade;
    vec3 col = fromYiq(yiq);

    // slight radial colour fringing
    vec2 dir = cc * Fringe;
    col.r = mix(col.r, texture(InSampler, uv + dir).r, 0.5);
    col.b = mix(col.b, texture(InSampler, uv - dir).b, 0.5);

    // grade: warm yellow, a bit washed out, lifted blacks, soft highlights
    float l = dot(col, vec3(0.299, 0.587, 0.114));
    col = mix(col, vec3(l), 0.12 * Grade);
    col *= mix(vec3(1.0), vec3(1.04, 1.04, 0.84), Grade);
    col = col * (1.0 - 0.05 * Grade) + vec3(0.04, 0.035, 0.02) * Grade;
    col = col / (1.0 + col * 0.12 * Grade);

    // faint tracking band glow + head switching tint
    col += band * (0.025 + 0.04 * hash12(vec2(uv.x * 400.0, t)));
    col = mix(col, col * vec3(0.92, 0.82, 1.08) + 0.03, head);

    // rare, faint dropout dashes
    vec2 cell = floor(vec2(uv.x * 26.0, uv.y * OutSize.y * 0.35));
    float h = hash12(cell + floor(t * 20.0) * 17.0);
    if (h > 1.0 - 0.0035 * Streaks) {
        float fx = fract(uv.x * 26.0);
        col += vec3(0.16) * smoothstep(0.0, 0.3, fx) * smoothstep(1.0, 0.5, fx);
    }

    // grain, vignette, flicker
    col += (hash12(gl_FragCoord.xy + fract(t * 7.3) * 431.0) - 0.5) * Grain;
    col *= 1.0 - Vignette * r2 * 1.8;
    col *= 1.0 + 0.01 * sin(t * 61.0);

    fragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}
