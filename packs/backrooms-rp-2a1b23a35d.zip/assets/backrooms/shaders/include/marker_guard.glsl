#ifndef BACKROOMS_MARKER_GUARD_GLSL
#define BACKROOMS_MARKER_GUARD_GLSL

// Sky marker test, shared by the skybox post effect and the entity/item/text/particle shaders so they can never
// disagree. A marker is one strong channel with the other two low AND almost equal to each other. "Almost equal"
// has a tolerance that grows with them, because fog and the lightmap lift all channels a little (seen: 203,7,8).
// Returns 0 = not a marker, 1 = blue (clouds), 2 = red (sunset), 3 = green (midnight).
int backrooms_marker(vec3 c) {
    float hi = max(c.r, max(c.g, c.b));
    if (hi < 0.45) return 0;
    float a, b;
    int kind;
    if (c.b >= c.r && c.b >= c.g) { a = c.r; b = c.g; kind = 1; }
    else if (c.r >= c.g) { a = c.g; b = c.b; kind = 2; }
    else { a = c.r; b = c.b; kind = 3; }
    float lo = max(a, b);
    if (lo > 0.15 * hi) return 0;
    if (abs(a - b) > 0.02 + 0.25 * lo) return 0;
    return kind;
}

// Entities, items, text and particles pass their final colour through this so they never test as a marker
// (a skin with a pure red patch would otherwise turn into sky). It nudges one of the two low channels up by about
// 10/255, which you can't see.
vec4 backrooms_guard(vec4 c) {
    if (backrooms_marker(c.rgb) == 0) return c;
    float s;
    if (c.b >= c.r && c.b >= c.g) { s = min(c.r, c.g); if (c.r >= c.g) c.r = s + (0.035 + 0.25 * s) / 0.75; else c.g = s + (0.035 + 0.25 * s) / 0.75; }
    else if (c.r >= c.g) { s = min(c.g, c.b); if (c.g >= c.b) c.g = s + (0.035 + 0.25 * s) / 0.75; else c.b = s + (0.035 + 0.25 * s) / 0.75; }
    else { s = min(c.r, c.b); if (c.r >= c.b) c.r = s + (0.035 + 0.25 * s) / 0.75; else c.b = s + (0.035 + 0.25 * s) / 0.75; }
    return c;
}

#endif