#ifndef JJK_FX_GLSL
#define JJK_FX_GLSL

// Reversal Red sprites, drawn procedurally on a 64x64 pixel grid. The quad's texture (jjk:item/fx/uv) stores
// each texel's own position (r = x*4+2, g = y*4+2), so ip = the sprite pixel, which keeps the look pixel-art.
// t = ticks.

float jjk_hash(vec2 p) {
    return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

float jjk_bayer(vec2 p) {
    vec2 m = mod(p, 4.0);
    int i = int(m.x) + int(m.y) * 4;
    const float B[16] = float[16](0.0, 8.0, 2.0, 10.0, 12.0, 4.0, 14.0, 6.0, 3.0, 11.0, 1.0, 9.0, 15.0, 7.0, 13.0, 5.0);
    return (B[i] + 0.5) / 16.0;
}

// tilted ring: distance of c from an ellipse (radius rr, squash sq, tilt ang), angle along it, front/back
vec3 jjk_ring(vec2 c, float rr, float sq, float ang) {
    float cs = cos(ang), sn = sin(ang);
    vec2 e = vec2(c.x * cs - c.y * sn, c.x * sn + c.y * cs);
    e.y /= sq;
    return vec3(abs(length(e) - rr), atan(e.y, e.x), e.y);
}

// Charging orb. ch = charge 0..1
vec4 jjk_orb(vec2 ip, float ch, float t) {
    vec2 c = ip + 0.5 - 32.0;
    float r = length(c);
    float a = atan(c.y, c.x);
    float R = mix(4.0, 9.0, ch) + 0.5 * sin(t * 0.35);
    float wob = (jjk_hash(vec2(floor((a + 3.1416) * 2.5), floor(t / 2.0))) - 0.5) * 1.4;
    vec4 col = vec4(0.0);

    // dithered glow
    float hR = R * 2.0;
    if (r < hR) {
        float g = clamp(1.0 - (r - R) / (hR - R), 0.0, 1.0);
        if (g * g * 0.85 > jjk_bayer(ip)) col = vec4(0.55, 0.02, 0.06, 1.0);
        if (g * g * g * 0.8 > jjk_bayer(ip + 2.0)) col = vec4(0.78, 0.05, 0.08, 1.0);
    }

    // rings behind the orb
    float spin = t * 0.045;
    vec3 r1 = jjk_ring(c, R * 1.55, 0.42, 0.55);
    bool a1 = r1.x < 0.62 && fract(r1.y / 6.2832 + spin) < 0.36;
    vec3 r2 = jjk_ring(c, R * 1.85, 0.55, -0.75);
    bool a2 = r2.x < 0.62 && fract(r2.y / 6.2832 - spin * 0.8) < 0.28;
    vec3 r3 = jjk_ring(c, R * 2.25, 0.35, 0.15);
    bool a3 = ch > 0.45 && r3.x < 0.6 && fract(r3.y / 6.2832 + spin * 1.3) < 0.2;
    if (a1 && r1.z < 0.0) col = vec4(0.95, 0.08, 0.12, 1.0);
    if (a2 && r2.z < 0.0) col = vec4(0.07, 0.0, 0.02, 1.0);
    if (a3 && r3.z < 0.0) col = vec4(0.85, 0.05, 0.1, 1.0);

    // specks
    for (int i = 0; i < 12; i++) {
        float fi = float(i);
        if (fi > 4.0 + ch * 8.0) break;
        float rr = R * (1.3 + fract(fi * 0.37) * 1.4) + sin(t * 0.08 + fi);
        float aa = fi * 2.399 + t * (0.02 + fract(fi * 0.13) * 0.05) * (mod(fi, 2.0) < 1.0 ? 1.0 : -1.0);
        vec2 s = floor(vec2(cos(aa), sin(aa)) * rr);
        if (floor(c) == s && jjk_hash(vec2(fi, floor(t / 3.0))) < 0.8) col = vec4(0.98, 0.2, 0.18, 1.0);
    }

    // body: hot core, orange, red, dark rim
    float rb = R + wob;
    if (r < rb) {
        col = vec4(0.93, 0.1, 0.1, 1.0);
        if (r < rb * 0.72) col = vec4(1.0, 0.36, 0.2, 1.0);
        if (r < rb * 0.4 + 0.6 * sin(t * 0.5)) col = vec4(1.0, 0.8, 0.62, 1.0);
        if (r > rb - 1.0) col = vec4(0.72, 0.04, 0.08, 1.0);
    }

    // rings in front
    if (a1 && r1.z >= 0.0) col = vec4(0.95, 0.08, 0.12, 1.0);
    if (a2 && r2.z >= 0.0) col = vec4(0.07, 0.0, 0.02, 1.0);
    if (a3 && r3.z >= 0.0) col = vec4(0.85, 0.05, 0.1, 1.0);
    return col;
}

// Explosion. p = progress 0..1
vec4 jjk_burst(vec2 ip, float p, float t) {
    vec2 c = ip + 0.5 - 32.0;
    float r = length(c);
    vec4 col = vec4(0.0);
    float ringR = mix(4.0, 27.0, sqrt(p));

    // big blocky splats
    vec2 cell6 = floor(c / 6.0);
    if (jjk_hash(cell6 + 3.7) > 0.9 && r < ringR * 1.15 && r > 6.0) {
        vec2 m = mod(c, 6.0);
        if (m.x >= 1.0 && m.x < 5.0 && m.y >= 1.0 && m.y < 5.0) col = vec4(0.62, 0.02, 0.06, 1.0);
    }

    // X lines (+ two off-angle ones), sliding outwards
    for (int i = 0; i < 6; i++) {
        float aa = i < 4 ? 0.7854 + float(i) * 1.5708 : (i == 4 ? 0.35 : 3.6);
        vec2 d = vec2(cos(aa), sin(aa));
        float along = dot(c, d);
        float off = abs(c.x * d.y - c.y * d.x);
        float w = i < 4 ? 0.75 : 0.55;
        if (off < w && along > mix(3.0, 26.0, p) && along < mix(16.0, 46.0, p)) col = vec4(0.88, 0.04, 0.12, 1.0);
    }

    // ring
    if (abs(r - ringR) < mix(1.3, 0.6, p)) col = vec4(0.92, 0.06, 0.12, 1.0);

    // red core blobs, shrinking
    vec2 cell3 = floor(c / 3.0);
    if (r < mix(13.0, 3.0, p) && jjk_hash(cell3 + floor(p * 5.0)) > 0.42) col = jjk_hash(cell3 * 1.3) > 0.5 ? vec4(0.95, 0.1, 0.1, 1.0) : vec4(0.78, 0.03, 0.08, 1.0);

    // dark specks
    vec2 cell4 = floor(c / 4.0);
    vec2 m4 = mod(c, 4.0);
    if (r < ringR && jjk_hash(cell4 * 1.7 + floor(p * 6.0)) > 0.84 && m4.x < 2.0 && m4.y < 2.0) col = vec4(0.06, 0.0, 0.02, 1.0);

    // fade out by dithering
    if (p > 0.55 && jjk_bayer(ip) < (p - 0.55) / 0.45) col.a = 0.0;
    return col;
}

#endif
