#version 330
#extension GL_ARB_separate_shader_objects : require

uniform sampler2D InSampler;

layout(location = 0) in vec2 texCoord;

layout(std140) uniform TintConfig {
    vec4 Params;
};

layout(location = 0) out vec4 fragColor;

// Red tint, Params.x = strength. Stronger at the edges.
void main() {
    vec3 col = texture(InSampler, texCoord).rgb;
    vec2 q = texCoord - 0.5;
    float s = Params.x * (0.55 + 0.45 * clamp(dot(q, q) * 3.0, 0.0, 1.0));
    float lum = dot(col, vec3(0.3, 0.59, 0.11));
    vec3 red = vec3(0.25 + lum * 0.95, lum * 0.22, lum * 0.26);
    fragColor = vec4(mix(col, red, s * 0.75), 1.0);
}
