#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif

layout(location = 2) in vec4 vertexColor;
layout(location = 3) in vec2 texCoord0;
#ifdef IS_GUI
#include <minecraft:globals.glsl>
layout(location = 4) flat in ivec2 hudInfo;
const vec3 HUD_PAL[16] = vec3[](
    vec3(1.0000, 1.0000, 1.0000),
    vec3(0.9569, 0.9569, 0.9647),
    vec3(0.6627, 0.6627, 0.7137),
    vec3(0.8471, 0.8471, 0.8706),
    vec3(1.0000, 1.0000, 1.0000),
    vec3(1.0000, 1.0000, 1.0000),
    vec3(0.6275, 0.6275, 0.6745),
    vec3(0.4863, 0.9216, 0.9647),
    vec3(0.4235, 0.4235, 0.4706),
    vec3(1.0000, 0.3843, 0.3843),
    vec3(0.5608, 0.8667, 0.9098),
    vec3(0.5451, 0.5451, 0.5882),
    vec3(1.0000, 0.3529, 0.3529),
    vec3(1.0000, 1.0000, 1.0000),
    vec3(1.0000, 1.0000, 1.0000),
    vec3(1.0000, 1.0000, 1.0000)
);
#endif

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    #endif

    #if !defined(IS_SEE_THROUGH) && !defined(IS_GUI)

    #ifdef OIT_ACCUMULATE
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    color = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
    #endif

    return color;
}

void main() {
    #ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
    #else
    vec4 texColor = texture(Sampler0, texCoord0);
    #endif

    vec4 color = texColor * vertexColor * ColorModulator;
#ifdef IS_GUI
    if (hudInfo.x > 0) {
        int m = hudInfo.y;
        vec3 tint;
        if (m >= 16) {
            // animation frame m-16 of 6, 2 ticks each
            if (hudInfo.x == 2) discard;
            int cur = int(mod(floor(GameTime * 24000.0 / 2.0), 6.0));
            if (m - 16 != cur) discard;
            tint = vec3(1.0);
        } else {
            if (m == 0 && hudInfo.x == 2) discard;
            tint = HUD_PAL[m] * (hudInfo.x == 2 ? 0.25 : 1.0);
        }
        color = texColor * vec4(tint, vertexColor.a) * ColorModulator;
    }
#endif

    if (color.a < 0.1) {
        discard;
    }

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
