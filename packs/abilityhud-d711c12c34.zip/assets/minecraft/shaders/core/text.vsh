#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;
#ifdef IS_GUI
layout(location = 4) out vec3 hotbarInfo;

// Hotbar: slots 1-5 hidden, slots 6-9 moved to the middle. info = (x from the screen centre before the
// move, move in GUI px, 1 inside the hotbar strip). Only orthographic (GUI) draws are touched.
vec3 moveHotbar(vec3 pos, out vec3 info) {
    info = vec3(0.0);
    if (ProjMat[3][3] < 0.99) return pos;
    // Minecraft lays the HUD out on ceil(window / scale) and centres with integer division
    float guiW = ceil(2.0 / ProjMat[0][0] - 0.01);
    float guiH = ceil(2.0 / abs(ProjMat[1][1]) - 0.01);
    float rel = pos.x - floor(guiW * 0.5);
    float up = guiH - pos.y;
    if (up < -1.5 || up > 23.5 || abs(rel) > 125.0) return pos;
    float shift = rel < -91.5 ? 50.0 : -50.0;
    info = vec3(rel, shift, 1.0);
    pos.x += shift;
    return pos;
}
#endif

void main() {
#ifdef IS_GUI
    vec3 pos = Position;
    hotbarInfo = vec3(0.0);
    vec3 c = Color.rgb;
    if (all(greaterThan(c, vec3(0.99))) || all(lessThan(abs(c - vec3(0.247)), vec3(0.012)))) {
        pos = moveHotbar(Position, hotbarInfo);
    }
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
#else
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;
}