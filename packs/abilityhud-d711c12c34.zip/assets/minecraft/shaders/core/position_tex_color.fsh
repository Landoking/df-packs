#version 330
#extension GL_ARB_separate_shader_objects : require

layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};
uniform sampler2D Sampler0;

layout(location = 0) in vec2 texCoord0;
layout(location = 1) in vec4 vertexColor;
layout(location = 2) in vec3 hotbarInfo;

layout(location = 0) out vec4 fragColor;

bool hiddenHotbarSlot(vec3 info) {
    return info.z > 0.5 && info.x >= -92.5 && info.x < 8.0 && info.y < 49.9;
}
void main() {
    vec4 color = texture(Sampler0, texCoord0) * vertexColor;
    if (color.a == 0.0 || hiddenHotbarSlot(hotbarInfo)) {
        discard;
    }
    fragColor = color * ColorModulator;
}