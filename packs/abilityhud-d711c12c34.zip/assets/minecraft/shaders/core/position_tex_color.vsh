#version 330
#extension GL_ARB_separate_shader_objects : require

layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

layout(location = 0) in vec3 Position;
layout(location = 1) in vec2 UV0;
layout(location = 2) in vec4 Color;

layout(location = 0) out vec2 texCoord0;
layout(location = 1) out vec4 vertexColor;
layout(location = 2) out vec3 hotbarInfo;

// Hotbar: slots 1-5 hidden, slots 6-9 moved to the middle. info = (x from the screen centre before the
// move, move in GUI px, 1 inside the hotbar strip). Only orthographic (GUI) draws are touched.
vec3 moveHotbar(vec3 pos, out vec3 info) {
    info = vec3(0.0);
    if (ProjMat[3][3] < 0.99) return pos;
    // Minecraft lays the HUD out on ceil(window / scale) and centres with integer division
    float guiW = ceil(2.0 / ProjMat[0][0] - 0.01);
    float guiH = ceil(2.0 / abs(ProjMat[1][1]) - 0.01);
    float rel = pos.x - floor(guiW * 0.5);
    float up = guiH - pos.y;
    if (up < -1.5 || up > 23.5 || abs(rel) > 125.0) return pos;
    float shift = rel < -91.5 ? 50.0 : -50.0;
    info = vec3(rel, shift, 1.0);
    pos.x += shift;
    return pos;
}
void main() {
    vec3 pos = moveHotbar(Position, hotbarInfo);
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
    texCoord0 = UV0;
    vertexColor = Color;
}