#version 330
#extension GL_ARB_separate_shader_objects : require

layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};
layout(location = 0) in vec4 vertexColor;
layout(location = 1) in float rightSide;
layout(location = 2) in vec3 hotbarInfo;

layout(location = 0) out vec4 fragColor;

bool hiddenHotbarSlot(vec3 info) {
    return info.z > 0.5 && info.x >= -92.5 && info.x < 8.0 && info.y < 49.9;
}
void main() {
    vec4 color = vertexColor;
    if (color.a == 0.0 || hiddenHotbarSlot(hotbarInfo)) {
        discard;
    }
    // scoreboard sidebar background: lines 0x4C000000, title 0x66000000
    if (rightSide > 0.2 && max(color.r, max(color.g, color.b)) < 0.004
        && (abs(color.a - 0.298) < 0.006 || abs(color.a - 0.4) < 0.006)) {
        discard;
    }
    fragColor = color * ColorModulator;
}