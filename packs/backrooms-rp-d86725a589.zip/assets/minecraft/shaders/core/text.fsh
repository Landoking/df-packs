#version 330
#extension GL_ARB_separate_shader_objects : require

// Vanilla 26.3 text.fsh + backrooms_guard (see backrooms:marker_guard.glsl).

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>
#include <backrooms:marker_guard.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif

layout(location = 2) in vec4 vertexColor;
layout(location = 3) in vec2 texCoord0;

#ifdef IS_GUI
// Backrooms HUD glyphs (text.vsh): hudTint.a = 1 for them; hudFill >= 0 cuts a bar fill at that many pixels
layout(location = 4) in float hudX;
layout(location = 5) flat in float hudFill;
layout(location = 6) flat in vec4 hudTint;
#endif

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    #endif

    #if !defined(IS_SEE_THROUGH) && !defined(IS_GUI)

    #ifdef OIT_ACCUMULATE
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    color = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
    #endif

    return color;
}

void main() {
    #ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
    #else
    vec4 texColor = texture(Sampler0, texCoord0);
    #endif

    vec4 color = texColor * vertexColor * ColorModulator;

    #ifdef IS_GUI
    if (hudTint.a > 0.5) {
        if (hudFill >= 0.0 && hudX > hudFill) {
            discard;
        }
        color = texColor * vec4(hudTint.rgb, vertexColor.a) * ColorModulator;
    }
    #endif

    if (color.a < 0.1) {
        discard;
    }

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = backrooms_guard(calculateFinalColor(color));
    #endif
}
