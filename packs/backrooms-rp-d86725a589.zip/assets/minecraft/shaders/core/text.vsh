#version 330
#extension GL_ARB_separate_shader_objects : require

// Vanilla 26.3 text.vsh + the Backrooms HUD.
// The plot sends the HUD as the action bar text every 2 ticks (DF func.HudUpdate, backrooms:hud font). Its glyphs
// are coloured with marker colours (red 254, green = element, blue = fill in pixels) and laid out with negative
// spaces so the whole text is 0 wide and every element starts at the action bar's origin: x = half the GUI width
// (integer), y = GUI height - 72 (vanilla draws it at height - 68, 4 px up). Its shadow is transparent
// (<shadow:#00000000>). Here each marked glyph is moved from there to its HUD spot:
//   green 1 sanity bar background, 2 sanity bar fill (blue = filled px of 91)  -> top right corner
//   green 3 "SANITY" label (menu font)                                          -> centred under that bar
//   green 4 stamina bar background, 5 stamina bar fill (blue = filled px of 91) -> right edge, turned upright
// Everything stays at 1 GUI pixel per texture pixel (vanilla boss bar art, no scaling, so no mixels). text.fsh cuts
// the fill at the blue value and draws the glyphs in their own texture colours instead of the marker colour.

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;

#ifdef IS_GUI
layout(location = 4) out float hudX;
layout(location = 5) flat out float hudFill;
layout(location = 6) flat out vec4 hudTint;

const float ORIGIN_UP = 72.0; // action bar text line: this many GUI px above the bottom
const float MARGIN = 6.0;   // GUI px from the screen edges
const float BAR = 91.0;     // bar length (7 boss bar cells of 13 px)
const float BAR_TOP = 2.0;  // a bar glyph's top below the title line (height 5, ascent 5)
const float LABEL_W = 33.0; // "SANITY" in the menu font
#endif

void main() {
    vec4 pos = ModelViewMat * vec4(Position, 1.0);
    gl_Position = ProjMat * pos;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;

#ifdef IS_GUI
    hudX = 0.0;
    hudFill = -1.0;
    hudTint = vec4(0.0);
    ivec3 c = ivec3(round(Color.rgb * 255.0));
    if (c.r == 254 && c.g >= 1 && c.g <= 5) {
        float guiW = floor(2.0 / abs(ProjMat[0][0]) + 0.5);
        float guiH = floor(2.0 / abs(ProjMat[1][1]) + 0.5);
        vec2 rel = pos.xy - vec2(floor(guiW * 0.5), guiH - ORIGIN_UP);
        vec2 p;
        hudTint = vec4(1.0, 1.0, 1.0, 1.0);
        if (c.g <= 2) {
            // sanity bar, top right
            vec2 a = vec2(guiW - MARGIN - BAR, MARGIN);
            p = a + vec2(rel.x, rel.y - BAR_TOP);
        } else if (c.g == 3) {
            // its label, centred under it (the menu font's glyph tops sit on the title line)
            vec2 a = vec2(guiW - MARGIN - BAR + floor((BAR - LABEL_W) * 0.5), MARGIN + 8.0);
            p = a + rel;
            hudTint = vec4(0.84, 0.76, 1.0, 1.0);
        } else {
            // stamina bar, upright on the right edge, centred: the bar's start (its left end) at the bottom, so it
            // empties from the top down
            vec2 a = vec2(guiW - MARGIN - 5.0, floor(guiH * 0.5 + BAR * 0.5));
            p = vec2(a.x + (rel.y - BAR_TOP), a.y - rel.x);
        }
        if (c.g == 2 || c.g == 5) {
            hudX = rel.x;
            hudFill = float(c.b);
        }
        gl_Position = ProjMat * vec4(p, pos.z, 1.0);
    }
#endif
}
