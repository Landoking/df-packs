#ifndef JJK_FX_GLSL
#define JJK_FX_GLSL

// Reversal Red sprites, drawn procedurally on a 64x64 pixel grid. The quad's texture (jjk:item/fx/uv) stores
// each texel's own position (r = x*4+2, g = y*4+2), so ip = the sprite pixel, which keeps the look pixel-art.
// t = ticks.

float jjk_hash(vec2 p) {
    return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

float jjk_bayer(vec2 p) {
    vec2 m = mod(p, 4.0);
    int i = int(m.x) + int(m.y) * 4;
    const float B[16] = float[16](0.0, 8.0, 2.0, 10.0, 12.0, 4.0, 14.0, 6.0, 3.0, 11.0, 1.0, 9.0, 15.0, 7.0, 13.0, 5.0);
    return (B[i] + 0.5) / 16.0;
}

// Glow ("gamma"): g = 0..1 light from nearby bright parts. Drawn under the crisp pixels as a translucent layer
// that goes from deep red at its edge to a hot pink-white near the source, in dithered steps so it stays
// pixel-art.
float jjk_glow(float d, float w) {
    return clamp(1.0 - d / w, 0.0, 1.0);
}
vec4 jjk_glowcol(float g, vec2 ip) {
    float al = floor(g * g * 6.0 + jjk_bayer(ip) * 0.999) / 6.0;
    vec3 c = mix(vec3(0.8, 0.02, 0.1), vec3(1.0, 0.62, 0.55), g * g);
    return vec4(c, al * 0.8);
}

// tilted ring: distance of c from an ellipse (radius rr, squash sq, tilt ang), angle along it, front/back
vec3 jjk_ring(vec2 c, float rr, float sq, float ang) {
    float cs = cos(ang), sn = sin(ang);
    vec2 e = vec2(c.x * cs - c.y * sn, c.x * sn + c.y * cs);
    e.y /= sq;
    return vec3(abs(length(e) - rr), atan(e.y, e.x), e.y);
}

// Charging orb. ch = charge 0..1. Alpha < 1 only in the glow.
vec4 jjk_orb(vec2 ip, float ch, float t) {
    vec2 c = ip + 0.5 - 32.0;
    float r = length(c);
    float a = atan(c.y, c.x);
    float R = mix(4.0, 9.0, ch) + 0.5 * sin(t * 0.35);
    float wob = (jjk_hash(vec2(floor((a + 3.1416) * 2.5), floor(t / 2.0))) - 0.5) * 1.4;
    vec4 col = vec4(0.0);

    // glow: a wide halo pulsing with the orb, plus light around the red rings (added after they are known)
    float G = jjk_glow(max(r - R, 0.0), R * (1.7 + 0.15 * sin(t * 0.4)) + 3.0);

    // rings behind the orb
    float spin = t * 0.045;
    vec3 r1 = jjk_ring(c, R * 1.55, 0.42, 0.55);
    bool a1 = r1.x < 0.8 && fract(r1.y / 6.2832 + spin) < 0.42;
    vec3 r2 = jjk_ring(c, R * 1.85, 0.55, -0.75);
    bool a2 = r2.x < 0.8 && fract(r2.y / 6.2832 - spin * 0.8) < 0.28;
    vec3 r3 = jjk_ring(c, R * 2.25, 0.35, 0.15);
    bool a3 = ch > 0.45 && r3.x < 0.75 && fract(r3.y / 6.2832 + spin * 1.3) < 0.2;
    float spinA1 = fract(r1.y / 6.2832 + spin);
    if (spinA1 < 0.42) G = max(G, jjk_glow(r1.x, 3.0) * 0.8);
    if (a3) G = max(G, jjk_glow(r3.x, 2.5) * 0.6);
    if (G > 0.0) col = jjk_glowcol(G, ip);
    if (a1 && r1.z < 0.0) col = vec4(1.0, 0.18, 0.2, 1.0);
    if (a2 && r2.z < 0.0) col = vec4(0.07, 0.0, 0.02, 1.0);
    if (a3 && r3.z < 0.0) col = vec4(0.85, 0.05, 0.1, 1.0);

    // specks
    for (int i = 0; i < 12; i++) {
        float fi = float(i);
        if (fi > 4.0 + ch * 8.0) break;
        float rr = R * (1.3 + fract(fi * 0.37) * 1.4) + sin(t * 0.08 + fi);
        float aa = fi * 2.399 + t * (0.02 + fract(fi * 0.13) * 0.05) * (mod(fi, 2.0) < 1.0 ? 1.0 : -1.0);
        vec2 s = floor(vec2(cos(aa), sin(aa)) * rr);
        if (floor(c) == s && jjk_hash(vec2(fi, floor(t / 3.0))) < 0.8) col = vec4(1.0, 0.45, 0.4, 1.0);
    }

    // body: hot core, orange, red, dark rim
    float rb = R + wob;
    if (r < rb) {
        col = vec4(1.0, 0.16, 0.14, 1.0);
        if (r < rb * 0.72) col = vec4(1.0, 0.48, 0.3, 1.0);
        if (r < rb * 0.4 + 0.6 * sin(t * 0.5)) col = vec4(1.0, 0.95, 0.86, 1.0);
        if (r > rb - 1.0) col = vec4(0.88, 0.06, 0.1, 1.0);
    }

    // rings in front
    if (a1 && r1.z >= 0.0) col = vec4(1.0, 0.18, 0.2, 1.0);
    if (a2 && r2.z >= 0.0) col = vec4(0.07, 0.0, 0.02, 1.0);
    if (a3 && r3.z >= 0.0) col = vec4(0.85, 0.05, 0.1, 1.0);
    return col;
}

// Explosion on a 128 grid (ip 0..127). p = progress 0..1. Eased motion, 1-2 px lines and specks, a soft hot
// core that cools and shrinks, two rings, and a dithered fade at the end.
vec4 jjk_burst(vec2 ip, float p, float t) {
    vec2 c = ip + 0.5 - 64.0;
    float r = length(c);
    float a = atan(c.y, c.x);
    float e = 1.0 - pow(1.0 - p, 3.0);           // ease out
    vec4 col = vec4(0.0);

    // glow layer: light around the ring, the lines and the core, dimming as it plays
    float R1 = mix(6.0, 58.0, e);
    float coreR = mix(16.0, 0.0, pow(p, 0.75)) * (1.0 + 0.08 * sin(a * 5.0 + p * 12.0));
    float G = jjk_glow(abs(r - R1), mix(9.0, 5.0, p)) * 0.85;
    G = max(G, jjk_glow(max(r - coreR, 0.0), coreR * 1.2 + 4.0));
    for (int i = 0; i < 4; i++) {
        vec2 d = vec2(cos(0.7854 + float(i) * 1.5708), sin(0.7854 + float(i) * 1.5708));
        float along = dot(c, d);
        float off = abs(c.x * d.y - c.y * d.x);
        float l0 = mix(6.0, 46.0, e), l1 = mix(22.0, 70.0, e);
        if (along > l0 - 2.0 && along < l1) G = max(G, jjk_glow(off, 4.0) * 0.7 * (1.0 - (along - l0) / max(l1 - l0, 1.0)));
    }
    G *= 1.0 - p * 0.75;
    if (G > 0.0) col = jjk_glowcol(G, ip);

    // X lines (and two off-angle ones): thin, tapered, sliding outwards
    for (int i = 0; i < 6; i++) {
        float aa = i < 4 ? 0.7854 + float(i) * 1.5708 : (i == 4 ? 0.32 : 3.55);
        vec2 d = vec2(cos(aa), sin(aa));
        float along = dot(c, d);
        float off = abs(c.x * d.y - c.y * d.x);
        float l0 = mix(6.0, 46.0, e), l1 = mix(22.0, 70.0, e) * (i < 4 ? 1.0 : 0.8);
        float k = clamp((along - l0) / max(l1 - l0, 1.0), 0.0, 1.0);
        float w = (i < 4 ? 1.6 : 1.1) * (1.0 - k) * (1.0 - p * 0.6);
        if (along > l0 && along < l1 && off < w) col = vec4(1.0, 0.2, 0.22, 1.0);
    }

    // outer ring and a thinner one trailing it
    if (abs(r - R1) < mix(2.0, 0.7, p)) col = vec4(1.0, mix(0.55, 0.15, p), mix(0.5, 0.18, p), 1.0);
    float R2 = mix(3.0, 40.0, 1.0 - pow(1.0 - p, 2.0));
    if (p > 0.08 && abs(r - R2) < 0.6 && fract(a / 6.2832 * 9.0 + p * 2.0) < 0.6) col = vec4(0.75, 0.03, 0.09, 1.0);

    // specks thrown outwards: small red and dark bits
    for (int i = 0; i < 28; i++) {
        float fi = float(i);
        float sa = fi * 2.399 + jjk_hash(vec2(fi, 3.0)) * 0.6;
        float sr = (8.0 + jjk_hash(vec2(fi, 7.0)) * 46.0) * e;
        vec2 sp = floor(vec2(cos(sa), sin(sa)) * sr);
        float sz = jjk_hash(vec2(fi, 11.0)) < 0.35 ? 2.0 : 1.0;
        vec2 q = floor(c) - sp;
        if (q.x >= 0.0 && q.y >= 0.0 && q.x < sz && q.y < sz && p < 0.92) {
            col = mod(fi, 4.0) < 1.0 ? vec4(0.08, 0.0, 0.02, 1.0) : vec4(1.0, 0.42, 0.38, 1.0);
        }
    }

    // core: white-hot then orange then red, shrinking, with a soft wobbling edge
    if (r < coreR) {
        float k = r / max(coreR, 0.001);
        vec3 hot = mix(vec3(1.0, 0.98, 0.92), vec3(1.0, 0.55, 0.35), clamp(p * 2.2, 0.0, 1.0));
        vec3 body = mix(vec3(1.0, 0.25, 0.2), vec3(0.75, 0.04, 0.08), p);
        col = vec4(k < 0.45 ? hot : body, 1.0);
        if (k > 0.85) col = vec4(0.9, 0.08, 0.1, 1.0);
    }

    // fade out by dithering
    if (p > 0.6 && jjk_bayer(ip) < (p - 0.6) / 0.4) col.a = 0.0;
    return col;
}

#endif
