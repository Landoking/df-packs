#version 330
#extension GL_ARB_separate_shader_objects : require
// Tints the screen toward Tint.rgb by Tint.a, with a slow pulse from GameTime. Key: template:tint

#include <minecraft:globals.glsl>

uniform sampler2D InSampler;

layout(location = 0) in vec2 texCoord;

layout(std140) uniform TintConfig {
    vec4 Tint;
};

layout(location = 0) out vec4 fragColor;

void main() {
    vec4 c = texture(InSampler, texCoord);
    float pulse = 0.85 + 0.15 * sin(GameTime * 1200.0 * 6.2831853);   // one pulse per second
    fragColor = vec4(mix(c.rgb, Tint.rgb, Tint.a * pulse), 1.0);
}
