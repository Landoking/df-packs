#version 330
#extension GL_ARB_separate_shader_objects : require

// Vanilla 26.3 item.fsh + the Backrooms camera probe (see item.vsh). Probe pixels x = 0..19 on the bottom row hold
// 16-bit values (red = high byte, green = low byte, blue = 173 as a "probe present" check):
//   0-2 world -Z as seen by the camera (view space, -1..1 -> 0..1), 3 ProjMat[0][0] / 8,
//   4-7 FogColor r g b a, 8 FogEnvironmentalStart / 1024, 9 FogEnvironmentalEnd / 1024,
//   10-12 world +Y as seen by the camera, 13 ProjMat[1][1] / 8,
//   14 FogRenderDistanceStart / 1024, 15 FogRenderDistanceEnd / 1024, 16-19 unused (0.5).
// The skybox pass uses the fog values to take the game's own fog back out of distant sky-window pixels.

#ifdef GLINT
#include <minecraft:globals.glsl>
#endif
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>
#include <backrooms:marker_guard.glsl>

uniform sampler2D Sampler0;

#ifdef GLINT
uniform sampler2D GlintSampler;
#endif

#ifndef OIT_ALPHA_ONLY
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif
layout(location = 2) in vec4 vertexColor;
#ifndef OIT_ALPHA_ONLY
layout(location = 3) in vec4 lightMapColor;
layout(location = 4) in vec4 overlayColor;
#endif
layout(location = 5) in vec2 texCoord0;
#ifdef GLINT
layout(location = 6) in vec2 texCoordGlint;
#endif
layout(location = 7) in float probeFlag;
layout(location = 8) flat in vec3 probeRight;
layout(location = 9) flat in vec3 probeUp;
layout(location = 10) flat in vec2 probeProj;

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

#ifndef OIT_ALPHA_ONLY
vec4 calculateFinalColor(vec4 color) {
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
    color *= lightMapColor;

    #ifdef GLINT
    vec4 glintColor = GlintAlpha * texture(GlintSampler, texCoordGlint);// Glint color modulator?
    // Matches BlendFuntion.GLINT
    color.rgb += glintColor.rgb * glintColor.rgb;
    #endif

    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    return apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
}

vec4 probeEncode(float v01) {
    float u = floor(clamp(v01, 0.0, 1.0) * 65535.0 + 0.5);
    float hi = floor(u / 256.0);
    float lo = u - hi * 256.0;
    return vec4(hi / 255.0, lo / 255.0, 173.0 / 255.0, 1.0);
}
#endif

void main() {
    if (probeFlag > 0.5) {
        #if defined(OIT_ALPHA_ONLY) || defined(OIT_ACCUMULATE)
        discard;
        #else
        // layout: see the top of this file (quad A draws x 0-9, quad B x 10-19; each quad's own normal)
        int i = int(gl_FragCoord.x);
        int j = i % 10;
        bool qa = i < 10;
        float v = 0.5;
        if (j == 0) v = probeRight.x * 0.5 + 0.5;
        else if (j == 1) v = probeRight.y * 0.5 + 0.5;
        else if (j == 2) v = probeRight.z * 0.5 + 0.5;
        else if (j == 3) v = (qa ? probeProj.x : probeProj.y) / 8.0;
        else if (qa) {
            if (j == 4) v = FogColor.r;
            else if (j == 5) v = FogColor.g;
            else if (j == 6) v = FogColor.b;
            else if (j == 7) v = FogColor.a;
            else if (j == 8) v = FogEnvironmentalStart / 1024.0;
            else v = FogEnvironmentalEnd / 1024.0;
        } else {
            if (j == 4) v = FogRenderDistanceStart / 1024.0;
            else if (j == 5) v = FogRenderDistanceEnd / 1024.0;
        }
        fragColor = probeEncode(v);
        return;
        #endif
    }

    vec4 color = texture(Sampler0, texCoord0);
    // the sky-cube paper props are meant to be markers (their unlit texel is a marker colour), everything else is
    // guarded
    vec3 raw = color.rgb;
    bool skyProp = backrooms_marker(raw) != 0 && max(raw.r, max(raw.g, raw.b)) > 0.99 && color.a > 0.99;
    #ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
    #endif

    color *= vertexColor * ColorModulator;

    #ifdef GLINT
    color.a = max(color.a, GlintAlpha);
    #endif

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = skyProp ? calculateFinalColor(color) : backrooms_guard(calculateFinalColor(color));
    #endif
}
