#version 330
#extension GL_ARB_separate_shader_objects : require

// Vanilla 26.3 text.fsh + backrooms_guard (see backrooms:marker_guard.glsl).

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>
#include <backrooms:marker_guard.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif

layout(location = 2) in vec4 vertexColor;
layout(location = 3) in vec2 texCoord0;

#ifdef IS_GUI
// Backrooms HUD (text.vsh). hudInfo.y = mode: 1 HUD art (own texture colours; hudInfo.x >= 0 cuts a fill at that
// many px, hudInfo.z = 1 makes the cut a slow wave, the liquid's surface), 2 banner background (black, 75% in the
// middle fading to 0 at the ends; hudInfo.x = half width). Everything is decided per texture/GUI px, so no mixels.
#include <minecraft:globals.glsl>
layout(location = 4) in vec2 hudLocal;
layout(location = 5) flat in vec4 hudInfo;
layout(location = 6) flat in vec4 hudTint;
#endif

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    #endif

    #if !defined(IS_SEE_THROUGH) && !defined(IS_GUI)

    #ifdef OIT_ACCUMULATE
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    color = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
    #endif

    return color;
}

void main() {
    #ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
    #else
    vec4 texColor = texture(Sampler0, texCoord0);
    #endif

    vec4 color = texColor * vertexColor * ColorModulator;

    #ifdef IS_GUI
    if (hudInfo.y > 0.5 && hudInfo.y < 1.5) {
        float fill = hudInfo.x;
        if (fill >= 0.0) {
            float col = floor(hudLocal.x);
            if (hudInfo.z > 0.5 && fill > 8.0) {
                // the liquid's surface moves a pixel back and forth, row by row
                float row = floor(hudLocal.y);
                fill += floor(sin(row * 0.9 + GameTime * 1200.0 * 2.5) * 1.5 + 0.5);
            }
            if (col >= fill) {
                discard;
            }
        }
        color = texColor * vec4(1.0, 1.0, 1.0, vertexColor.a) * ColorModulator;
        if (color.a < 0.02) {
            discard;
        }
    } else if (hudInfo.y > 1.5) {
        float hw = hudInfo.x;
        float x = abs(floor(hudLocal.x) + 0.5);
        float fade = max(1.0, min(48.0, hw * 0.6));
        float a = 0.75 * clamp((hw - x) / fade, 0.0, 1.0);
        a = floor(a * 16.0 + 0.5) / 16.0;
        if (a <= 0.0) {
            discard;
        }
        color = vec4(0.0, 0.0, 0.0, a * vertexColor.a) * ColorModulator;
    }
    #endif

    if (color.a < 0.1) {
        discard;
    }

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = backrooms_guard(calculateFinalColor(color));
    #endif
}
