#version 330
#extension GL_ARB_separate_shader_objects : require

// Handheld camera sway: a slow drift and roll, like a camera held in a hand. It is NOT tied to footsteps (post
// effects can't see them, so a step bob ran out of sync with the game's own view bobbing and felt off), and every
// variant uses the same frequencies, so DF switching idle / walk / run (func.CameraBob) only changes how strong it
// is, never jumps the phase. Strengths in BobConfig (post_effect/bob_idle.json, bob_walk.json, bob_run.json);
// Steps is unused (kept so the uniform block stays the same).

#include <minecraft:globals.glsl>

uniform sampler2D InSampler;

layout(location = 0) in vec2 texCoord;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(std140) uniform BobConfig {
    vec2 Amp;
    float Steps;
    float Roll;
    float Zoom;
};

layout(location = 0) out vec4 fragColor;

const float TAU = 6.2831853;

void main() {
    float t = GameTime * 1200.0;
    float aspect = OutSize.x / OutSize.y;
    vec2 off = vec2(sin(t * 0.9) + 0.35 * sin(t * 2.3 + 0.4), sin(t * 0.63 + 1.3) + 0.35 * cos(t * 1.9)) * Amp;
    float r = (sin(t * 0.8 + 0.6) + 0.3 * sin(t * 1.7)) * Roll;
    vec2 p = (texCoord - 0.5) * vec2(aspect, 1.0);
    p = mat2(cos(r), -sin(r), sin(r), cos(r)) * p;
    vec2 uv = p / vec2(aspect, 1.0) + 0.5 + off;
    // fixed zoom (same in every variant, so switching idle/walk/run never pops) hides the moved frame's edge
    uv = 0.5 + (uv - 0.5) * (1.0 - Zoom);
    fragColor = vec4(texture(InSampler, uv).rgb, 1.0);
}
