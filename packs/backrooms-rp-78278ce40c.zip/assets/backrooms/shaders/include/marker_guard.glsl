#ifndef BACKROOMS_MARKER_GUARD_GLSL
#define BACKROOMS_MARKER_GUARD_GLSL

// Sky marker test, shared by the skybox post effect and the entity/item/text/particle shaders so they can never
// disagree. Each marker colour is coded by a RATIO, which lighting can't change (light multiplies all three channels
// by the same amount, and a 0 channel stays 0):
//   clouds   (0, 64, 255)  blue full, green = 1/4 of it, red 0
//   sunset   (255, 0, 64)  red full,  blue  = 1/4 of it, green 0
//   midnight (64, 255, 0)  green full, red = 1/4 of it, blue 0
// (mapping.json "skybox"). Earlier versions used pure primaries (255,0,0)...; real textures have those too (the
// hotel carpet, red doors, ball pit balls) and turned into sky. A zero channel plus an exact 1:4 pair is something
// block textures practically never have. Far away the game's own fog shifts the ratio; the levels' distance fog
// covers that range anyway. Brightness is not tested: on screen the strong channel is well below 1.
// Returns 0 = not a marker, 1 = clouds, 2 = sunset, 3 = midnight.
int backrooms_marker(vec3 c) {
    float s, q, z;
    int kind;
    if (c.b >= c.r && c.b >= c.g) { s = c.b; q = c.g; z = c.r; kind = 1; }
    else if (c.r >= c.g) { s = c.r; q = c.b; z = c.g; kind = 2; }
    else { s = c.g; q = c.r; z = c.b; kind = 3; }
    if (s < 0.2) return 0;
    if (z > 0.016) return 0;                                  // ~4/255
    if (abs(q - 0.25 * s) > 0.012 + 0.035 * s) return 0;      // the 1:4 pair (a little rounding slack)
    return kind;
}

// Entities, items, text and particles pass their final colour through this so they never test as a marker:
// it lifts the zero channel by ~13/255, which you can't see.
vec4 backrooms_guard(vec4 c) {
    int k = backrooms_marker(c.rgb);
    if (k == 1) c.r += 0.05;
    else if (k == 2) c.g += 0.05;
    else if (k == 3) c.b += 0.05;
    return c;
}

#endif
