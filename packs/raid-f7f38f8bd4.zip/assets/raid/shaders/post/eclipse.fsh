#version 330
#extension GL_ARB_separate_shader_objects : require
// Eclipse grade for the Seraph's last phase. Key: raid:eclipse

#include <minecraft:globals.glsl>

uniform sampler2D InSampler;

layout(location = 0) in vec2 texCoord;

layout(std140) uniform EclipseConfig {
    float Strength;
};

layout(location = 0) out vec4 fragColor;

void main() {
    vec3 c = texture(InSampler, texCoord).rgb;
    float lum = dot(c, vec3(0.299, 0.587, 0.114));
    vec3 graded = mix(vec3(lum), c, 0.35) * vec3(1.08, 0.5, 0.46);
    vec2 d = (texCoord - 0.5) * vec2(1.25, 1.0);
    float vig = 1.0 - smoothstep(0.28, 0.78, length(d));
    float pulse = 0.5 + 0.5 * sin(GameTime * 1200.0 * 2.4);
    vec3 rim = vec3(0.6, 0.02, 0.05) * (1.0 - vig) * (0.55 + 0.45 * pulse);
    vec3 outc = graded * mix(0.4, 1.0, vig) + rim;
    fragColor = vec4(mix(c, outc, Strength), 1.0);
}