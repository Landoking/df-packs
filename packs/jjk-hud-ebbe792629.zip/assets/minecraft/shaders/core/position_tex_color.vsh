#version 330
#extension GL_ARB_separate_shader_objects : require

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl and projection.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

layout(location = 0) in vec3 Position;
layout(location = 1) in vec2 UV0;
layout(location = 2) in vec4 Color;

layout(location = 0) out vec2 texCoord0;
layout(location = 1) out vec4 vertexColor;
layout(location = 2) out vec3 dollInfo;   // xy: pixel inside the paperdoll quad, z: 1 on the paperdoll

uniform sampler2D Sampler0;

// JJK combat lock: the item in main-inventory slot 10 paints its atlas cell pure magenta; a quad drawn exactly on
// that slot whose corner texels are magenta is stretched over the three inventory buttons (info.z = 2).
bool jjkMagic(vec2 uv) {
    ivec2 ts = textureSize(Sampler0, 0);
    vec2 p = uv * vec2(ts);
    for (int i = 0; i < 4; i++) {
        ivec2 q = ivec2(floor(p + vec2(i % 2 == 0 ? -0.5 : 0.5, i < 2 ? -0.5 : 0.5)));
        if (q.x < 0 || q.y < 0 || q.x >= ts.x || q.y >= ts.y) continue;
        vec4 c = texelFetch(Sampler0, q, 0);
        if (c.r > 0.97 && c.g < 0.03 && c.b > 0.97 && c.a > 0.97) return true;
    }
    return false;
}
vec3 jjkLock(vec3 pos, out vec3 info) {
    info = vec3(0.0);
    if (ProjMat[3][3] < 0.99) return pos;
    float guiW = ceil(2.0 / ProjMat[0][0] - 0.01);
    float guiH = ceil(2.0 / abs(ProjMat[1][1]) - 0.01);
    vec2 lt = vec2(floor((guiW - 176.0) * 0.5), floor((guiH - 166.0) * 0.5));
    vec2 a = lt + vec2(8.0, 84.0), b = a + vec2(16.0);
    bool ax = abs(pos.x - a.x) < 0.01, bx = abs(pos.x - b.x) < 0.01;
    bool ay = abs(pos.y - a.y) < 0.01, by = abs(pos.y - b.y) < 0.01;
    if ((ax || bx) && (ay || by) && jjkMagic(UV0)) {
        info = vec3(bx ? 160.0 : 0.0, by ? 54.0 : 0.0, 2.0);
        pos.xy = lt + vec2(bx ? 168.0 : 8.0, by ? 137.0 : 83.0);
    }
    return pos;
}

// JJK: recognise the inventory paperdoll quad and move it (startup shader: no #include possible)
vec3 jjkDoll(vec3 pos, out vec3 info) {
    info = vec3(0.0);
    if (ProjMat[3][3] < 0.99) return pos;
    float guiW = ceil(2.0 / ProjMat[0][0] - 0.01);
    float guiH = ceil(2.0 / abs(ProjMat[1][1]) - 0.01);
    vec2 lt = vec2(floor((guiW - 176.0) * 0.5), floor((guiH - 166.0) * 0.5));
    vec2 a = lt + vec2(26.0, 8.0), b = a + vec2(49.0, 70.0);
    bool ax = abs(pos.x - a.x) < 0.01, bx = abs(pos.x - b.x) < 0.01;
    bool ay = abs(pos.y - a.y) < 0.01, by = abs(pos.y - b.y) < 0.01;
    bool uvCorner = (abs(UV0.x) < 0.0001 || abs(UV0.x - 1.0) < 0.0001) && (abs(UV0.y) < 0.0001 || abs(UV0.y - 1.0) < 0.0001);
    if ((ax || bx) && (ay || by) && uvCorner) {
        info = vec3(bx ? 49.0 : 0.0, by ? 70.0 : 0.0, 1.0);
        pos.xy += vec2(-79.0, 78.0);
    }
    return pos;
}

void main() {
    vec3 jjkP = jjkDoll(Position, dollInfo);
    vec3 jjkI;
    vec3 jjkQ = jjkLock(jjkP, jjkI);
    if (jjkI.z > 0.5) { jjkP = jjkQ; dollInfo = jjkI; }
    gl_Position = ProjMat * ModelViewMat * vec4(jjkP, 1.0);

    texCoord0 = UV0;
    vertexColor = Color;
}
