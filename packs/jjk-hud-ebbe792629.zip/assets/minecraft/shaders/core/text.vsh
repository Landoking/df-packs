#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;
#ifdef IS_GUI
// JJK HUD: action-bar glyphs coloured #FE<anchor*4><mode*4> (shadow: #3F<anchor><mode>) are moved from the
// action bar to their anchor (corner 0 top-left, 1 screen centre, 2 bottom centre) and scaled by .w.
layout(location = 4) flat out ivec2 hudInfo;   // x: 0 not ours, 1 glyph, 2 shadow; y: mode
const vec4 HUD_ANCH[16] = vec4[](
    vec4(0.0),
    vec4(0.0, 2.0, 2.0, 1.0),
    vec4(0.0, 7.0, 10.0, 3.0),
    vec4(0.0, 36.0, 8.0, 1.0),
    vec4(0.0, 36.0, 19.0, 1.0),
    vec4(0.0, 6.0, 33.0, 1.0),
    vec4(0.0, 2.0, 44.0, 1.0),
    vec4(1.0, 36.0, -25.0, 1.0),
    vec4(1.0, 36.0, -4.0, 1.0),
    vec4(1.0, 36.0, 12.0, 1.0),
    vec4(2.0, -46.0, -52.0, 1.0),
    vec4(2.0, -46.0, -61.0, 1.0),
    vec4(2.0, -91.0, -22.0, 1.0),
    vec4(2.0, -92.0, -23.0, 1.0),
    vec4(2.0, 50.0, -49.0, 1.0),
    vec4(2.0, -91.0, -39.0, 1.0)
);
vec3 hudMove(vec3 pos, vec4 col, out ivec2 info) {
    info = ivec2(0);
    if (ProjMat[3][3] < 0.99) return pos;
    ivec3 c = ivec3(col.rgb * 255.0 + 0.5);
    int kind = 0; int a = 0; int m = 0;
    if (c.r == 254 && (c.g & 3) == 0 && (c.b & 3) == 0) { kind = 1; a = c.g >> 2; m = c.b >> 2; }
    else if (c.r == 63) { kind = 2; a = c.g; m = c.b; }
    if (kind == 0 || a < 1 || a > 15 || m > 31) return pos;
    float guiW = ceil(2.0 / ProjMat[0][0] - 0.01);
    float guiH = ceil(2.0 / abs(ProjMat[1][1]) - 0.01);
    vec2 origin = vec2(floor(guiW * 0.5), guiH - 68.0 + (-4.0));
    vec4 an = HUD_ANCH[a];
    vec2 corner = an.x < 0.5 ? vec2(0.0) : (an.x < 1.5 ? vec2(floor(guiW * 0.5), floor(guiH * 0.5)) : vec2(floor(guiW * 0.5), guiH));
    pos.xy = corner + an.yz + (pos.xy - origin) * an.w;
    info = ivec2(kind, m);
    return pos;
}
#endif

void main() {
#ifdef IS_GUI
    vec3 hudPos = hudMove(Position, Color, hudInfo);
    gl_Position = ProjMat * ModelViewMat * vec4(hudPos, 1.0);
#else
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;
}
