#version 330
#extension GL_ARB_separate_shader_objects : require

uniform sampler2D InSampler;

layout(location = 0) in vec2 texCoord;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(std140) uniform RippleConfig {
    vec4 Params;
};

layout(location = 0) out vec4 fragColor;

void main() {
    float p = Params.x, flash = Params.y, amp = Params.z;
    vec2 asp = vec2(OutSize.x / OutSize.y, 1.0);
    vec2 d = (texCoord - 0.5) * asp;
    float r = length(d);
    vec2 dir = r > 0.0001 ? d / r : vec2(0.0);
    // ripple ring: pushes the picture outwards around it
    float R = mix(0.05, 1.1, p);
    float rw = (r - R) / 0.06;
    float w = exp(-rw * rw);
    vec2 uv = texCoord - dir / asp * w * 0.035 * amp * (1.0 - p * 0.6);
    // colour split, strongest at the start
    float ca = (0.006 * amp + 0.004 * flash) * (1.0 - p);
    vec3 col;
    col.r = texture(InSampler, clamp(uv + dir / asp * ca, 0.001, 0.999)).r;
    col.g = texture(InSampler, clamp(uv, 0.001, 0.999)).g;
    col.b = texture(InSampler, clamp(uv - dir / asp * ca, 0.001, 0.999)).b;
    // ring tint + flash
    col = mix(col, vec3(1.0, 0.45, 0.95), w * 0.35 * amp * (1.0 - p));
    float fl = flash * pow(1.0 - p, 1.6);
    col = mix(col, vec3(1.0, 0.32, 0.92), fl * 0.85);
    col = mix(col, vec3(1.0, 0.9, 1.0), fl * fl * 0.5);
    fragColor = vec4(col, 1.0);
}
