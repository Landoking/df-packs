#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:globals.glsl>

uniform sampler2D InSampler;

layout(location = 0) in vec2 texCoord;

layout(std140) uniform TintConfig {
    vec4 Params;
};

layout(location = 0) out vec4 fragColor;

// Screen hit: the picture shakes slightly (a few sines of the game time, up to ~0.7% of the screen) and is
// tinted red or blue, stronger at the edges.
void main() {
    float t = GameTime * 24000.0;
    vec2 off = vec2(sin(t * 2.3) + 0.5 * sin(t * 5.7), cos(t * 2.9) + 0.5 * sin(t * 4.3)) * 0.0045 * Params.y;
    vec2 uv = clamp(texCoord + off, vec2(0.001), vec2(0.999));
    vec3 col = texture(InSampler, uv).rgb;
    vec2 q = texCoord - 0.5;
    float s = Params.x * (0.55 + 0.45 * clamp(dot(q, q) * 3.0, 0.0, 1.0));
    float lum = dot(col, vec3(0.3, 0.59, 0.11));
    vec3 tint = Params.z > 0.5 ? vec3(lum * 0.2, 0.05 + lum * 0.5, 0.3 + lum * 0.95) : vec3(0.25 + lum * 0.95, lum * 0.22, lum * 0.26);
    fragColor = vec4(mix(col, tint, s * 0.75), 1.0);
}
