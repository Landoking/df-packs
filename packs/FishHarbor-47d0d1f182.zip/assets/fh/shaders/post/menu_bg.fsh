#version 330
#extension GL_ARB_separate_shader_objects : require
// Fish Harbor menu background (key fh:menu_bg): an animated underwater scene that replaces the whole world view.
// Sun rays, caustics, rising bubbles, fish swimming past and a sandy seabed with swaying kelp, drawn on a pixel grid
// about one GUI pixel big so it matches the menu art. The HUD (the menu itself) draws on top.

#include <minecraft:globals.glsl>

uniform sampler2D InSampler;

layout(location = 0) in vec2 texCoord;

layout(std140) uniform OceanConfig {
    float GuiHeight;   // pixel grid: screen height / GuiHeight = one cell
    float Opacity;     // 1 = world fully hidden
};

layout(location = 0) out vec4 fragColor;

float hash(float n) { return fract(sin(n * 127.1) * 43758.5453); }
float hash2(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }

float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    float a = hash2(i);
    float b = hash2(i + vec2(1.0, 0.0));
    float c = hash2(i + vec2(0.0, 1.0));
    float d = hash2(i + vec2(1.0, 1.0));
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

// fish silhouette: body ellipse + tail triangle, facing +x (dir = 1) or -x (dir = -1)
float fishShape(vec2 p, vec2 c, float s, float dir) {
    vec2 q = (p - c) / s;
    q.x *= dir;
    float body = step(q.x * q.x / 1.0 + q.y * q.y / 0.18, 1.0);
    float tail = step(-1.5, q.x) * step(q.x, -0.85) * step(abs(q.y), (-0.85 - q.x) * 0.9 + 0.05);
    return max(body, tail);
}

void main() {
    vec4 world = texture(InSampler, texCoord);

    // pixel grid in GUI-ish units, origin top-left
    float cell = max(1.0, floor(ScreenSize.y / GuiHeight));
    vec2 px = floor(vec2(texCoord.x, 1.0 - texCoord.y) * ScreenSize / cell);
    vec2 res = ScreenSize / cell;
    vec2 uv = (px + 0.5) / res;               // 0..1, y down
    float aspect = res.x / res.y;
    vec2 p = vec2(uv.x * aspect, uv.y);

    float t = GameTime * 1200.0;              // seconds

    // depth gradient: sunlit surface -> deep blue
    vec3 top = vec3(0.30, 0.76, 0.88);
    vec3 mid = vec3(0.09, 0.40, 0.58);
    vec3 deep = vec3(0.02, 0.07, 0.15);
    vec3 col = uv.y < 0.45 ? mix(top, mid, uv.y / 0.45) : mix(mid, deep, (uv.y - 0.45) / 0.55);

    // the water surface seen from below: a shimmering bright band at the very top
    float surf = 0.035 + 0.012 * sin(p.x * 9.0 + t * 1.3) + 0.008 * sin(p.x * 23.0 - t * 2.1);
    if (uv.y < surf) {
        col = mix(vec3(0.75, 0.95, 1.0), top, uv.y / surf * 0.6);
    } else if (uv.y < surf + 0.008) {
        col = vec3(0.90, 1.0, 1.0);
    }

    // sun rays from the upper left, swaying
    float rayAngle = 0.35;
    float rx = p.x + uv.y * rayAngle;
    float rays = 0.0;
    rays += smoothstep(0.55, 1.0, sin(rx * 7.0 + sin(t * 0.25) * 0.8));
    rays += smoothstep(0.65, 1.0, sin(rx * 13.0 - t * 0.18 + 1.7)) * 0.6;
    rays += smoothstep(0.75, 1.0, sin(rx * 4.0 + t * 0.12 + 4.0)) * 0.8;
    rays *= (1.0 - smoothstep(0.0, 0.85, uv.y));
    col += vec3(0.55, 0.85, 0.95) * rays * 0.16;

    // caustics: two drifting noise layers, brightest near the surface
    float ca = noise(p * 9.0 + vec2(t * 0.35, t * 0.22));
    float cb = noise(p * 13.0 - vec2(t * 0.28, -t * 0.31));
    float caustic = pow(1.0 - abs(ca - cb), 10.0);
    col += vec3(0.65, 0.95, 1.0) * caustic * 0.20 * (1.0 - smoothstep(0.05, 0.75, uv.y));

    // fish passing in the background (three depths, slower and darker further away)
    for (int i = 0; i < 6; i++) {
        float fi = float(i);
        float depth = 0.45 + 0.55 * hash(fi + 3.0);
        float speed = (0.025 + 0.03 * hash(fi + 7.0)) * depth;
        float dir = hash(fi + 11.0) > 0.5 ? 1.0 : -1.0;
        float span = aspect + 0.4;
        float fx = mod(hash(fi + 5.0) * span + t * speed * dir, span) - 0.2;
        float fy = 0.25 + 0.5 * hash(fi + 13.0) + 0.015 * sin(t * 0.9 + fi * 2.0);
        float s = 0.022 * depth;
        float f = fishShape(p, vec2(fx, fy), s, dir);
        col = mix(col, col * (0.35 + 0.35 * (1.0 - depth)) + vec3(0.0, 0.03, 0.05), f * 0.85);
    }

    // seabed: sand dunes with darker ridges, kelp swaying in front
    float bed = 0.86 + 0.035 * sin(p.x * 3.1 + 1.3) + 0.02 * sin(p.x * 7.7);
    if (uv.y > bed) {
        float d = (uv.y - bed) / (1.0 - bed);
        vec3 sand = mix(vec3(0.42, 0.40, 0.30), vec3(0.16, 0.16, 0.14), d);
        sand += 0.04 * step(0.5, hash2(px));          // grain
        col = mix(col, sand * 0.75, 0.9);
    }
    for (int k = 0; k < 7; k++) {
        float fk = float(k);
        float kx = (fk + 0.3 + 0.4 * hash(fk + 21.0)) / 7.0 * aspect;
        float kh = 0.18 + 0.16 * hash(fk + 31.0);
        float base = 0.86 + 0.035 * sin(kx * 3.1 + 1.3) + 0.02 * sin(kx * 7.7) + 0.01;
        float h = (base - uv.y) / kh;                 // 0 at root .. 1 at tip
        if (h > 0.0 && h < 1.0) {
            float sway = sin(t * 0.8 + fk * 1.7 + h * 3.0) * 0.035 * h;
            float w = 0.006 * (1.0 - h * 0.6);
            if (abs(p.x - kx - sway) < w) {
                col = mix(col, vec3(0.10, 0.36, 0.22) * (0.7 + 0.3 * h), 0.9);
            }
        }
    }

    // bubbles rising in columns
    for (int b = 0; b < 14; b++) {
        float fb = float(b);
        float bx = hash(fb + 41.0) * aspect;
        float sp = 0.05 + 0.06 * hash(fb + 51.0);
        float by = 1.0 - fract(t * sp + hash(fb + 61.0));
        bx += 0.012 * sin(t * 2.0 + fb);
        float r = 0.004 + 0.004 * hash(fb + 71.0);
        float d = length(vec2(p.x - bx, uv.y - by));
        float ring = step(d, r) - step(d, r * 0.45);
        float glint = step(length(vec2(p.x - bx + r * 0.35, uv.y - by + r * 0.35)), r * 0.35);
        col = mix(col, vec3(0.80, 0.97, 1.0), clamp(ring * 0.55 + glint * 0.8, 0.0, 1.0) * step(surf + 0.01, by));
    }

    // vignette + slight dither so the gradient doesn't band
    vec2 v = uv - 0.5;
    col *= 1.0 - dot(v, v) * 0.9;
    col += (hash2(px + floor(t * 4.0)) - 0.5) / 255.0 * 2.0;

    fragColor = vec4(mix(world.rgb, col, Opacity), 1.0);
}
