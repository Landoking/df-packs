#version 330
#extension GL_ARB_separate_shader_objects : require

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};

uniform sampler2D Sampler0;

layout(location = 0) in vec2 texCoord0;
layout(location = 1) in vec4 vertexColor;
layout(location = 2) in vec3 dollInfo;

// copy of globals.glsl (startup shader: no #include possible)
layout(std140) uniform Globals {
    ivec3 CameraBlockPos;
    float GlintAlpha;
    vec3 CameraOffset;
    float GameTime;
    vec2 ScreenSize;
    int MenuBlurRadius;
    int UseRgss;
};

// JJK paperdoll frame: ink edge, rim, drifting dark checkerboard behind the model
vec3 jjkDollBg(vec2 p) {
    float e = min(min(p.x, p.y), min(48.0 - p.x, 69.0 - p.y));
    if (e < 0.5) return vec3(0.0392, 0.0392, 0.0510);
    if (e < 1.5) return (p.x < 1.5 || p.y < 1.5) ? vec3(0.7255, 0.7255, 0.7765) : vec3(0.5608, 0.5608, 0.6118);
    float t = floor(GameTime * 24000.0 / 2.0);
    vec2 q = floor((p + vec2(t)) / 4.0);
    return mod(q.x + q.y, 2.0) < 1.0 ? vec3(0.1176, 0.1176, 0.1412) : vec3(0.1490, 0.1490, 0.1765);
}

layout(location = 0) out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0) * vertexColor;
    if (dollInfo.z > 0.5) {
        vec2 p = floor(dollInfo.xy);
        vec3 bg = jjkDollBg(p);
        float edge = min(min(p.x, p.y), min(48.0 - p.x, 69.0 - p.y));
        fragColor = vec4(edge < 1.5 ? bg : color.rgb + bg * (1.0 - color.a), 1.0) * ColorModulator;
        return;
    }
    if (color.a == 0.0) {
        discard;
    }
    fragColor = color * ColorModulator;
}
