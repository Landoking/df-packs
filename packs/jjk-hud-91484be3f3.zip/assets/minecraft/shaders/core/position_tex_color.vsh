#version 330
#extension GL_ARB_separate_shader_objects : require

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl and projection.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

layout(location = 0) in vec3 Position;
layout(location = 1) in vec2 UV0;
layout(location = 2) in vec4 Color;

layout(location = 0) out vec2 texCoord0;
layout(location = 1) out vec4 vertexColor;

// JJK: move the inventory paperdoll left (startup shader: no #include possible)
vec3 jjkDoll(vec3 pos) {
    if (ProjMat[3][3] < 0.99) return pos;
    float guiW = ceil(2.0 / ProjMat[0][0] - 0.01);
    float guiH = ceil(2.0 / abs(ProjMat[1][1]) - 0.01);
    vec2 lt = vec2(floor((guiW - 176.0) * 0.5), floor((guiH - 166.0) * 0.5));
    vec2 a = lt + vec2(26.0, 8.0), b = lt + vec2(75.0, 78.0);
    bool onX = abs(pos.x - a.x) < 0.01 || abs(pos.x - b.x) < 0.01;
    bool onY = abs(pos.y - a.y) < 0.01 || abs(pos.y - b.y) < 0.01;
    if (onX && onY) pos.x += -18.0;
    return pos;
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(jjkDoll(Position), 1.0);

    texCoord0 = UV0;
    vertexColor = Color;
}
