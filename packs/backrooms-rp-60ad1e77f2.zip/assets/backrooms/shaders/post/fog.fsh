#version 330
#extension GL_ARB_separate_shader_objects : require

// Distance fog for generated levels (goes with the bodycam look): everything fades into FogColor between Start and
// End blocks away, and empty space (unloaded chunks, the void past the level) is pure fog, so you never see where
// the level ends. Reads the depth buffer, so func.ApplyEffects runs it before the camera bob moves the picture.
// A little slow noise in the fog keeps it from looking like a flat wall. Variants: post_effect/fog_*.json.
// Pit fog (PitDark > 0, Level 0): anything below the level's floor fades into near-black the deeper it is (fully dark
// PitDepth blocks down), so the holes look bottomless. Needs the camera probe (core/item.fsh): the camera's height
// above the floor (pixel 16; DF draws the probe at the floor), world up and the projection. It runs before the
// skybox pass hides the probe pixels (func.ApplyEffects puts the fog first in levels without sky).

#include <minecraft:globals.glsl>
#include <backrooms:sky_noise.glsl>

uniform sampler2D InSampler;
uniform sampler2D DepthSampler;

layout(location = 0) in vec2 texCoord;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(std140) uniform FogConfig {
    vec3 FogColor;
    float Start;
    float End;
    float Density;
    float PitDark;
    float PitDepth;
};

layout(location = 0) out vec4 fragColor;

const int PROBE_W = 20;
const vec3 PIT_COLOR = vec3(0.012, 0.010, 0.006);

float probeValue(int i, out bool ok) {
    vec4 c = texelFetch(InSampler, ivec2(i, 0), 0);
    ok = abs(c.b * 255.0 - 173.0) < 0.6;
    return (floor(c.r * 255.0 + 0.5) * 256.0 + floor(c.g * 255.0 + 0.5)) / 65535.0;
}

// how far below the floor the pixel is (blocks; <= 0 = above it), or -1 without probe data
float belowFloor(vec2 ndc, float viewDepth) {
    bool a, b, c, d, e, g;
    vec3 up = vec3(probeValue(10, a), probeValue(11, b), probeValue(12, c)) * 2.0 - 1.0;
    vec2 proj = vec2(probeValue(3, d), probeValue(13, e)) * 8.0;
    float camH = probeValue(16, g) * 128.0 - 64.0;
    if (!(a && b && c && d && e && g) || proj.x < 0.05 || proj.y < 0.05) return -1.0;
    vec3 vp = vec3(ndc.x / proj.x, ndc.y / proj.y, -1.0) * viewDepth;
    return -(camH + dot(vp, normalize(up)));
}

void main() {
    vec3 col = texture(InSampler, texCoord).rgb;
    ivec2 px = ivec2(gl_FragCoord.xy);
    if (px.y == 0 && px.x < PROBE_W) {
        // leave the probe's own pixels alone (the skybox pass still reads and then hides them)
        fragColor = vec4(col, 1.0);
        return;
    }
    float depth = texture(DepthSampler, texCoord).r;
    // 26.3 uses reversed depth (vanilla integrate_depth.fsh: 0 = nothing drawn): view depth = near / depth, with
    // the near plane at 0.05. Nothing drawn (the void past the loaded chunks) = infinitely far = full fog.
    bool empty = depth <= 0.0;
    float dist = empty ? 1e6 : 0.05 / depth;
    // distance from the centre of the screen grows towards the edges: use the real ray length so the fog is round
    vec2 ndc = texCoord * 2.0 - 1.0;
    dist *= length(vec3(ndc * vec2(OutSize.x / OutSize.y, 1.0) * 0.6, 1.0));
    float t = clamp((dist - Start) / max(End - Start, 0.001), 0.0, 1.0);
    float f = 1.0 - exp(-t * t * Density);
    f = empty ? 1.0 : clamp(f / (1.0 - exp(-Density)), 0.0, 1.0);
    // slow drifting variation (screen space, very subtle)
    float s = GameTime * 1200.0;
    float n = vnoise(texCoord * vec2(3.0, 2.0) + vec2(s * 0.03, s * 0.017)) - 0.5;
    vec3 fog = FogColor * (1.0 + n * 0.12);
    vec3 outc = mix(col, fog, f);
    if (PitDark > 0.0 && !empty) {
        float b = belowFloor(ndc, 0.05 / depth);
        float p = smoothstep(0.4, max(PitDepth, 0.5), b) * PitDark;
        outc = mix(outc, PIT_COLOR * (1.0 + n * 0.3), p);
    }
    fragColor = vec4(outc, 1.0);
}
