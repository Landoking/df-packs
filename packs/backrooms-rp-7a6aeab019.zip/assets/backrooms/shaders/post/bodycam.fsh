#version 330
#extension GL_ARB_separate_shader_objects : require

// Bodycam footage look (for the Poolrooms, usable on any level): wide-angle barrel lens, edge colour fringing,
// over-sharpened digital picture, bright bloom on sky windows / water glare, clipped highlights and cool shadows,
// tiny handheld jitter, sensor grain, vignette, and a "REC" + running clock overlay drawn with a 3x5 pixel font.
// Strengths: post_effect/bodycam.json (BodycamConfig).

#include <minecraft:globals.glsl>
#include <backrooms:sky_noise.glsl>

uniform sampler2D InSampler;
uniform sampler2D BloomSampler;

layout(location = 0) in vec2 texCoord;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(std140) uniform BodycamConfig {
    float Lens;
    float Fringe;
    float Sharpen;
    float Bloom;
    float Grade;
    float Grain;
    float Vignette;
    float Overlay;
};

layout(location = 0) out vec4 fragColor;

// 3x5 glyphs, row-major from the top-left bit (bit 14): 0-9, then ':' (10), 'R' (11), 'E' (12), 'C' (13)
const int GLYPHS[14] = int[14](31599, 11415, 29671, 29647, 23497, 31183, 31215, 29257, 31727, 31695, 1040, 27565, 31143, 31015);

// 1 if pixel p (screen px, origin bottom-left) is lit by glyph g drawn at o with scale s
float glyph(int g, vec2 p, vec2 o, float s) {
    vec2 q = floor((p - o) / s);
    if (q.x < 0.0 || q.y < 0.0 || q.x > 2.0 || q.y > 4.0) return 0.0;
    int bit = 14 - (int(4.0 - q.y) * 3 + int(q.x));
    return float((GLYPHS[g] >> bit) & 1);
}

void main() {
    float t = GameTime * 1200.0;           // seconds, loops every 20 minutes
    vec2 px = 1.0 / OutSize;
    float aspect = OutSize.x / OutSize.y;

    // lens: barrel distortion, zoomed so the corners just reach the frame; tiny handheld jitter
    vec2 cc = texCoord - 0.5;
    vec2 ca = cc * vec2(aspect, 1.0);
    float r2 = dot(ca, ca) / (0.25 * (aspect * aspect + 1.0));   // 0 centre .. 1 corner
    vec2 uv = 0.5 + cc * (1.0 + Lens * r2) / (1.0 + Lens);
    uv += (vec2(vnoise(vec2(t * 3.1, 1.7)), vnoise(vec2(4.3, t * 2.7))) - 0.5) * 0.0016;
    uv = clamp(uv, px, 1.0 - px);

    // picture: fringed edges, then an unsharp mask (cheap digital sensors over-sharpen)
    vec2 dir = (uv - 0.5) * Fringe * r2;
    vec3 col = vec3(texture(InSampler, uv + dir).r, texture(InSampler, uv).g, texture(InSampler, uv - dir).b);
    vec3 blur = (texture(InSampler, uv + vec2(px.x, 0.0)).rgb + texture(InSampler, uv - vec2(px.x, 0.0)).rgb
        + texture(InSampler, uv + vec2(0.0, px.y)).rgb + texture(InSampler, uv - vec2(0.0, px.y)).rgb) * 0.25;
    col += (col - blur) * Sharpen;

    // bloom from the blurred bright pass, same lens
    col += texture(BloomSampler, uv).rgb * Bloom;

    // grade: a little desaturated, cool shadows, highlights pushed up and clipped like an auto-exposed sensor
    float l = dot(col, vec3(0.299, 0.587, 0.114));
    col = mix(col, vec3(l), 0.18 * Grade);
    col = mix(col, col * vec3(0.92, 1.0, 1.06), Grade * (1.0 - smoothstep(0.0, 0.6, l)));
    col = (col - 0.5) * (1.0 + 0.12 * Grade) + 0.5 + 0.04 * Grade;
    // soft clip above 0.8: rises smoothly towards 1, never darker for brighter input (bloom can push past 1)
    vec3 over = max(col - 0.8, 0.0);
    col = min(col, 0.8) + 0.2 * (1.0 - exp(-over / 0.2));

    // grain (stronger in the dark), vignette
    float gN = hash12(gl_FragCoord.xy + fract(t * 9.7) * 517.0) - 0.5;
    col += gN * Grain * (1.4 - l);
    col *= 1.0 - Vignette * r2;

    // overlay: blinking red dot + REC top left, running clock bottom right
    if (Overlay > 0.5) {
        float s = max(2.0, floor(OutSize.y / 160.0));
        vec2 p = gl_FragCoord.xy, m = vec2(s * 6.0);
        float ink = 0.0;
        vec2 dotC = vec2(m.x + s * 2.5, OutSize.y - m.y - s * 2.5);
        float blink = step(0.5, fract(t * 0.5));
        float red = (1.0 - step(s * 2.2, length(p - dotC))) * blink;
        vec2 o = vec2(m.x + s * 7.0, OutSize.y - m.y - s * 5.0);
        ink += glyph(11, p, o, s) + glyph(12, p, o + vec2(s * 4.0, 0.0), s) + glyph(13, p, o + vec2(s * 8.0, 0.0), s);
        float secs = 3.0 * 3600.0 + 14.0 * 60.0 + floor(t);
        int hh = int(mod(floor(secs / 3600.0), 24.0)), mm = int(mod(floor(secs / 60.0), 60.0)), ss = int(mod(secs, 60.0));
        int d[8] = int[8](hh / 10, hh - hh / 10 * 10, 10, mm / 10, mm - mm / 10 * 10, 10, ss / 10, ss - ss / 10 * 10);
        vec2 c0 = vec2(OutSize.x - m.x - s * 32.0, m.y);
        for (int i = 0; i < 8; i++) ink += glyph(d[i], p, c0 + vec2(float(i) * s * 4.0, 0.0), s);
        col = mix(col, vec3(0.95, 0.12, 0.1), red);
        col = mix(col, vec3(0.97), clamp(ink, 0.0, 1.0) * 0.9);
    }

    fragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}
