#version 330
#extension GL_ARB_separate_shader_objects : require

// DiamondDoku background: pixelated crystal caustics over deep navy, replacing the whole world view (the UI is
// drawn on the HUD, above post effects). Burst 0..1 = win shockwave progress, Hurt 0..1 = red flash strength.

#include <minecraft:globals.glsl>

uniform sampler2D InSampler;

layout(location = 0) in vec2 texCoord;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(std140) uniform DDConfig {
    float Burst;
    float Hurt;
};

layout(location = 0) out vec4 fragColor;

float caustic(vec2 p, float t) {
    vec2 i = p;
    float c = 1.0;
    float inten = 0.005;
    for (int n = 0; n < 5; n++) {
        float tt = t * (1.0 - (3.5 / float(n + 1)));
        i = p + vec2(cos(tt - i.x) + sin(tt + i.y), sin(tt - i.y) + cos(tt + i.x));
        c += 1.0 / length(vec2(p.x / (sin(i.x + tt) / inten), p.y / (cos(i.y + tt) / inten)));
    }
    c /= 5.0;
    c = 1.17 - pow(c, 1.4);
    return pow(abs(c), 8.0);
}

float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }

void main() {
    // pixel grid ~ 2 GUI-ish pixels at common scales (ScreenSize from Globals; keep InSampler "used")
    vec2 size = max(ScreenSize, vec2(64.0)) + texture(InSampler, texCoord).rg * 1e-6;
    float block = max(4.0, floor(size.y / 160.0));
    vec2 cell = floor(texCoord * size / block);
    vec2 frag = cell * block + block * 0.5;
    vec2 uv = (frag - size * 0.5) / size.y;                // centred, aspect-correct
    float t = mod(GameTime * 1200.0, 1200.0);               // seconds (wraps every 20 min)

    // two layers of caustics, slightly offset like light through a prism
    // the iteration is tuned for coordinates around -250 (tileable over 2*pi)
    vec2 p = mod(uv * 4.0 + vec2(t * 0.02, -t * 0.015), 6.28318) - 250.0;
    float c1 = caustic(p, t * 0.45);
    float c2 = caustic(mod(uv * 5.2 + 3.1, 6.28318) - 250.0, t * 0.38 + 7.0);

    float v = 0.5 - uv.y * 0.6;
    vec3 col = mix(vec3(0.016, 0.026, 0.066), vec3(0.040, 0.075, 0.165), clamp(v, 0.0, 1.0));
    col += vec3(0.20, 0.55, 0.90) * c1 * 0.20;
    col += vec3(0.50, 0.35, 0.90) * c2 * 0.08;
    col += vec3(0.80, 0.95, 1.00) * pow(c1 * c2, 1.5) * 0.18;

    // drifting pixel stars: 3 parallax layers moving slowly down-left, each star twinkling
    for (int L = 0; L < 3; L++) {
        float fl = float(L);
        float cs = 9.0 + fl * 5.0;                       // star cell size (pixel blocks)
        float sp = 0.6 + fl * 0.9;                       // drift speed (blocks per second)
        vec2 q = cell + vec2(t * sp, t * sp * 0.35) + fl * 37.0;
        vec2 id = floor(q / cs);
        float h = hash(id + fl * 13.1);
        if (h > 0.55) {
            vec2 sp2 = floor(vec2(hash(id + 3.7), hash(id + 9.1)) * (cs - 1.0));
            vec2 lp = floor(q - id * cs);
            float tw = 0.45 + 0.55 * sin(t * (1.2 + h * 2.0) + h * 60.0);
            float b = (0.18 + 0.22 * fl) * max(tw, 0.0);
            if (lp == sp2) col += vec3(0.75, 0.90, 1.00) * b;
        }
    }

    // vignette
    col *= 1.0 - 0.5 * dot(uv, uv);

    // win: expanding ring + flash
    if (Burst > 0.0) {
        float r = length(uv);
        float ring = smoothstep(0.06, 0.0, abs(r - Burst * 1.1));
        col += vec3(0.6, 0.95, 1.0) * ring * (1.0 - Burst) * 1.4;
        col += vec3(0.3, 0.55, 0.8) * (1.0 - Burst) * 0.35;
    }
    // hurt: red vignette
    if (Hurt > 0.0) {
        col = mix(col, vec3(0.55, 0.05, 0.10), Hurt * clamp(0.25 + dot(uv, uv) * 1.6, 0.0, 1.0));
    }

    // posterise a little for the pixel look
    col = floor(col * 48.0 + 0.5) / 48.0;
    fragColor = vec4(col, 1.0);
}
