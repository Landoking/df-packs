#version 330
#extension GL_ARB_separate_shader_objects : require

// DiamondDoku: vanilla 26.3 core/text.vsh + one marker. Text coloured #FE<G><B> with B = FE or FF is drawn
// untinted and moved down by (G - 128) * 2 + (B & 1) GUI pixels. Used for <head:name> glyphs, which can't be
// positioned with font ascents. All other text is untouched.

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;

void main() {
    vec3 pos = Position;
    vec4 col = Color;
    ivec3 c = ivec3(round(Color.rgb * 255.0));
    if (c.r == 254 && c.b >= 254) {
        pos.y += float((c.g - 128) * 2 + (c.b - 254));
        col = vec4(1.0, 1.0, 1.0, Color.a);
    }
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);
    vertexColor = col * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = col;
#endif
    texCoord0 = UV0;
}
