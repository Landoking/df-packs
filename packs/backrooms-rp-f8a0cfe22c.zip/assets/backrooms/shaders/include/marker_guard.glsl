#ifndef BACKROOMS_MARKER_GUARD_GLSL
#define BACKROOMS_MARKER_GUARD_GLSL

// Sky marker test, shared by the skybox post effect and the entity/item/text/particle shaders so they can never
// disagree. Marker textures are pure blue / red / green: the two other channels are exactly 0, and stay 0 on screen
// whatever the lighting does to the strong one (0 x light = 0; in game the strong channel comes out well below 1, so
// brightness can't be part of the test). So: one channel clearly lit, the other two at (almost exactly) zero.
// The low-channel limit is tight on purpose: a loose test (any strong channel with two low, equal ones) also caught
// dark red block pixels in shadow - red doors, carpets, ball pit balls - and drew sky on them. Blocks can't be
// guarded like entities (Sodium draws terrain with its own shaders), so this test is the only protection there.
// Far away, where the game's own fog lifts the zero channels, the levels' distance fog already covers everything.
// Returns 0 = not a marker, 1 = blue (clouds), 2 = red (sunset), 3 = green (midnight).
int backrooms_marker(vec3 c) {
    float hi = max(c.r, max(c.g, c.b));
    if (hi < 0.2) return 0;
    float a, b;
    int kind;
    if (c.b >= c.r && c.b >= c.g) { a = c.r; b = c.g; kind = 1; }
    else if (c.r >= c.g) { a = c.g; b = c.b; kind = 2; }
    else { a = c.r; b = c.b; kind = 3; }
    if (max(a, b) > 0.016) return 0;      // ~4/255
    if (abs(a - b) > 0.012) return 0;
    return kind;
}

// Entities, items, text and particles pass their final colour through this so they never test as a marker
// (a skin with a pure red patch would otherwise turn into sky). It nudges one of the two low channels up by about
// 10/255, which you can't see.
vec4 backrooms_guard(vec4 c) {
    if (backrooms_marker(c.rgb) == 0) return c;
    float s;
    if (c.b >= c.r && c.b >= c.g) { s = min(c.r, c.g); if (c.r >= c.g) c.r = s + (0.035 + 0.25 * s) / 0.75; else c.g = s + (0.035 + 0.25 * s) / 0.75; }
    else if (c.r >= c.g) { s = min(c.g, c.b); if (c.g >= c.b) c.g = s + (0.035 + 0.25 * s) / 0.75; else c.b = s + (0.035 + 0.25 * s) / 0.75; }
    else { s = min(c.r, c.b); if (c.r >= c.b) c.r = s + (0.035 + 0.25 * s) / 0.75; else c.b = s + (0.035 + 0.25 * s) / 0.75; }
    return c;
}

#endif