#ifndef JJK_ARM_GLSL
#define JJK_ARM_GLSL

// Ragdoll body parts drawn with a plain player head on an item display.
//
// Plot code marks a display as body part k (1..7) by adding -1024*k to the Y of its
// transformation translation. The vertex shader sees a camera-relative position more than
// 512 blocks below the camera, which no real entity can be at (display view range is far
// smaller), takes k from it and moves the vertex back. The fragment shader then reads the
// skin texels of that body part instead of the head's.
//
// The head cube (8x8x8, box UV at 0,0 and the hat at 32,0) is stretched by the display's
// scale to the part's size, so each head face only needs an affine remap to the same face
// of the part's box UV layout.
//
//  k  part                 w  h  d   base     overlay
//  1  body                 8 12  4   16,16    16,32
//  2  right arm            4 12  4   40,16    40,32
//  3  left arm             4 12  4   32,48    48,48
//  4  right leg            4 12  4    0,16     0,32
//  5  left leg             4 12  4   16,48     0,48
//  6  right arm (slim)     3 12  4   40,16    40,32
//  7  left arm (slim)      3 12  4   32,48    48,48

#define RAGDOLL_SPACING 1024.0
#define RAGDOLL_PARTS 7

const vec3 RAGDOLL_DIM[8] = vec3[8](
    vec3(8.0, 8.0, 8.0),
    vec3(8.0, 12.0, 4.0),
    vec3(4.0, 12.0, 4.0),
    vec3(4.0, 12.0, 4.0),
    vec3(4.0, 12.0, 4.0),
    vec3(4.0, 12.0, 4.0),
    vec3(3.0, 12.0, 4.0),
    vec3(3.0, 12.0, 4.0)
);

// xy = base layer origin, zw = overlay layer origin (pixels in the 64x64 skin)
const vec4 RAGDOLL_ORIGIN[8] = vec4[8](
    vec4( 0.0,  0.0, 32.0,  0.0),
    vec4(16.0, 16.0, 16.0, 32.0),
    vec4(40.0, 16.0, 40.0, 32.0),
    vec4(32.0, 48.0, 48.0, 48.0),
    vec4( 0.0, 16.0,  0.0, 32.0),
    vec4(16.0, 48.0,  0.0, 48.0),
    vec4(40.0, 16.0, 40.0, 32.0),
    vec4(32.0, 48.0, 48.0, 48.0)
);

// Vertex side: returns the part id (0 = not a ragdoll part) and fixes the position.
int ragdoll_decode(inout vec3 pos) {
    if (pos.y > -RAGDOLL_SPACING * 0.5) {
        return 0;
    }
    int k = int(floor((-pos.y + RAGDOLL_SPACING * 0.5) / RAGDOLL_SPACING));
    if (k < 1 || k > RAGDOLL_PARTS) {
        return 0;
    }
    pos.y += float(k) * RAGDOLL_SPACING;
    return k;
}

// Fragment side: head-cube UV (0..1 of a 64x64 skin) -> the same face on body part k.
vec2 ragdoll_remap(int k, vec2 uv) {
    vec2 p = uv * 64.0;
    bool overlay = p.x >= 32.0;
    vec4 org = RAGDOLL_ORIGIN[k];
    vec2 o = overlay ? org.zw : org.xy;
    float u = overlay ? p.x - 32.0 : p.x;
    float v = p.y;
    float w = RAGDOLL_DIM[k].x;
    float h = RAGDOLL_DIM[k].y;
    float d = RAGDOLL_DIM[k].z;

    vec2 lo;
    vec2 size;
    vec2 t;
    if (v < 8.0) {
        if (u < 16.0) {             // top
            lo = o + vec2(d, 0.0);
            size = vec2(w, d);
            t = vec2(u - 8.0, v);
        } else {                    // bottom
            lo = o + vec2(d + w, 0.0);
            size = vec2(w, d);
            t = vec2(u - 16.0, v);
        }
    } else {
        float vv = v - 8.0;
        if (u < 8.0) {              // right side
            lo = o + vec2(0.0, d);
            size = vec2(d, h);
            t = vec2(u, vv);
        } else if (u < 16.0) {      // front
            lo = o + vec2(d, d);
            size = vec2(w, h);
            t = vec2(u - 8.0, vv);
        } else if (u < 24.0) {      // left side
            lo = o + vec2(d + w, d);
            size = vec2(d, h);
            t = vec2(u - 16.0, vv);
        } else {                    // back
            lo = o + vec2(2.0 * d + w, d);
            size = vec2(w, h);
            t = vec2(u - 24.0, vv);
        }
    }
    vec2 q = lo + clamp(t / 8.0, 0.0, 1.0) * size;
    q = clamp(q, lo + 0.001, lo + size - 0.001);
    return q / 64.0;
}


// First-person arm: head-cube UV -> right arm (classic k=2, slim k=6). Size per face, measured from screen
// derivatives of the view-space position against the head texels: front/back/top/bottom faces give the width
// (classic .25, slim .1875 blocks over 8 texels), side faces the height (classic .75, slim .85). The hat layer
// is 8.5/8 bigger.
vec2 jjk_arm_uv(vec2 tc, vec3 dpx, vec3 dpy, vec2 dux, vec2 duy) {
    vec2 p = tc * 64.0;
    bool hat = p.x >= 32.0;
    float u = hat ? p.x - 32.0 : p.x;
    float v = p.y;
    float det = dux.x * duy.y - duy.x * dux.y;
    bool slim = false;
    if (abs(det) > 1e-9) {
        vec3 dPdu = (dpx * duy.y - dpy * dux.y) / det;
        vec3 dPdv = (dpy * dux.x - dpx * duy.x) / det;
        float k = hat ? 8.5 / 8.0 : 1.0;
        bool side = v >= 8.0 && (u < 8.0 || (u >= 16.0 && u < 24.0));
        slim = side ? length(dPdv) * 8.0 > 0.80 * k : length(dPdu) * 8.0 < 0.22 * k;
    }
    return ragdoll_remap(slim ? 6 : 2, tc);
}

#endif
