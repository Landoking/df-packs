#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:globals.glsl>

uniform sampler2D InSampler;

layout(location = 0) in vec2 texCoord;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(std140) uniform RedConfig {
    vec4 Params;
};

layout(location = 0) out vec4 fragColor;

float bayer(vec2 g) { vec2 m = mod(g, 2.0); return m.x == m.y ? (m.x == 0.0 ? 0.0 : 0.5) : (m.x == 0.0 ? 0.75 : 0.25); }

void main() {
    vec3 col = texture(InSampler, texCoord).rgb;
    float ch = Params.x;
    float px = max(2.0, floor(OutSize.y / 170.0));
    vec2 g = floor(texCoord * OutSize / px) - floor(OutSize * 0.5 / px);
    vec2 gc = g + 0.5;
    float r = length(gc);
    float t = mod(GameTime * 24000.0, 2400.0);
    float a = atan(gc.y, gc.x);
    // edge tint
    vec2 q = texCoord - 0.5;
    col = mix(col, col * vec3(1.05, 0.72, 0.74), clamp(dot(q, q) * 2.4, 0.0, 1.0) * (0.25 + 0.35 * ch));
    float R1 = mix(5.0, 9.0, ch);
    float R0 = R1 * 0.45;
    float pulse = 0.5 + 0.5 * sin(t * 0.6);
    // glow halo
    float gl = clamp(1.0 - (r - R1) / (R1 * 1.6), 0.0, 1.0);
    if (r > R1 && gl * gl * (0.55 + 0.25 * pulse) > bayer(g) * 0.9 + 0.08) col = mix(col, vec3(0.75, 0.04, 0.08), 0.55 * gl);
    // rings: inner one clockwise, outer tilted one counter-clockwise
    float ra = R1 * 1.55;
    if (abs(r - ra) < 0.75 && fract(a / 6.2832 * 3.0 + t * 0.035) < 0.34) col = vec3(0.92, 0.10, 0.16);
    vec2 e = vec2(gc.x * cos(0.5) - gc.y * sin(0.5), (gc.x * sin(0.5) + gc.y * cos(0.5)) * 1.45);
    float rb = length(e), ab = atan(e.y, e.x);
    if (ch > 0.3 && abs(rb - R1 * 2.05) < 0.8 && fract(ab / 6.2832 * 2.0 - t * 0.025) < 0.22) col = vec3(0.85, 0.06, 0.12);
    // specks
    for (int i = 0; i < 10; i++) {
        float fi = float(i);
        float rr = R1 * (1.25 + mod(fi * 0.37, 1.0) * 1.5);
        float aa = fi * 2.399 + t * (0.03 + mod(fi * 0.13, 0.05)) * (mod(fi, 2.0) < 1.0 ? 1.0 : -1.0);
        vec2 s = floor(vec2(cos(aa), sin(aa)) * rr);
        float sz = mod(fi, 3.0) < 1.0 ? 1.0 : 0.0;
        if (g.x >= s.x && g.x <= s.x + sz && g.y >= s.y && g.y <= s.y + sz && float(i) < 4.0 + ch * 6.0) col = vec3(0.95, 0.18, 0.2);
    }
    // body + core
    if (r < R1) col = r < R0 ? vec3(1.0, 0.86, 0.76) : (r < R1 * 0.72 ? vec3(1.0, 0.42, 0.30) : vec3(0.95, 0.12, 0.14));
    if (r < R1 && r > R1 - 1.0) col = vec3(0.70, 0.05, 0.09);
    fragColor = vec4(col, 1.0);
}
