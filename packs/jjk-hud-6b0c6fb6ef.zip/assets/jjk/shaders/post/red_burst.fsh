#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:globals.glsl>

uniform sampler2D InSampler;

layout(location = 0) in vec2 texCoord;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(std140) uniform BurstConfig {
    vec4 Params;
};

layout(location = 0) out vec4 fragColor;

void main() {
    vec3 col = texture(InSampler, texCoord).rgb;
    float p = Params.x;
    float px = max(2.0, floor(OutSize.y / 140.0));
    vec2 g = floor(texCoord * OutSize / px) - floor(OutSize * 0.5 / px);
    vec2 gc = g + 0.5;
    float r = length(gc);
    float maxR = length(OutSize / px) * 0.5;
    col = mix(col, vec3(0.9, 0.06, 0.1), (1.0 - p) * 0.45);
    // streak lines: 8 directions, a moving band along each
    float band0 = mix(4.0, maxR * 0.9, p), band1 = band0 + mix(18.0, 40.0, p);
    for (int i = 0; i < 8; i++) {
        float aa = float(i) * 0.7854 + 0.3927 * float(i / 4);
        vec2 d = vec2(cos(aa), sin(aa));
        float along = dot(gc, d);
        float off = abs(gc.x * d.y - gc.y * d.x);
        float w = (i % 2 == 0) ? 0.9 : 0.6;
        if (along > band0 && along < band1 && off < w) col = mix(col, vec3(0.95, 0.12, 0.16), 1.0 - p * 0.6);
    }
    // ring
    if (abs(r - mix(6.0, maxR, p)) < 1.0) col = mix(col, vec3(0.85, 0.08, 0.12), 1.0 - p);
    // dark specks
    vec2 cell = floor(g / 6.0);
    float h = fract(sin(dot(cell, vec2(12.9898, 78.233))) * 43758.5453);
    if (h > 0.86 && mod(g.x, 6.0) < 1.0 && mod(g.y, 6.0) < 1.0 && r < maxR * (0.3 + p)) col = mix(col, vec3(0.08, 0.01, 0.02), 1.0 - p * 0.5);
    fragColor = vec4(col, 1.0);
}
