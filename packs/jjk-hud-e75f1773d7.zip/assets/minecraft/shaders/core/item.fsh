#version 330
#extension GL_ARB_separate_shader_objects : require

#ifdef GLINT
#include <minecraft:globals.glsl>
#endif
#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:oit.glsl>
#ifndef GLINT
#include <minecraft:globals.glsl>
#endif
#include <jjk:fx.glsl>

uniform sampler2D Sampler0;

#ifdef GLINT
uniform sampler2D GlintSampler;
#endif

#ifndef OIT_ALPHA_ONLY
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
#endif
layout(location = 2) in vec4 vertexColor;
#ifndef OIT_ALPHA_ONLY
layout(location = 3) in vec4 lightMapColor;
layout(location = 4) in vec4 overlayColor;
#endif
layout(location = 5) in vec2 texCoord0;
layout(location = 7) in float jjkDist;
layout(location = 8) flat in int jjkFx;
layout(location = 9) flat in float jjkParam;
#ifdef GLINT
layout(location = 6) in vec2 texCoordGlint;
#endif

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

#ifndef OIT_ALPHA_ONLY
vec4 calculateFinalColor(vec4 color) {
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
    color *= lightMapColor;

    #ifdef GLINT
    vec4 glintColor = GlintAlpha * texture(GlintSampler, texCoordGlint);// Glint color modulator?
    // Matches BlendFuntion.GLINT
    color.rgb += glintColor.rgb * glintColor.rgb;
    #endif

    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif

    return apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
}
#endif

void main() {
    if (jjkFx > 0) {
        if ((jjkFx == 2 || jjkFx == 5) && jjkDist < 1.8) {
            discard;
        }
        vec2 jip = floor(texture(Sampler0, texCoord0).rg * 255.0 / 2.0);
        float jt = mod(GameTime * 24000.0, 24000.0);
        vec2 jip64 = floor(jip / 2.0);
        vec4 fx;
        if (jjkFx == 3) fx = jjk_burst(jip, jjkParam, jt);
        else if (jjkFx == 6) fx = jjk_blueify(jjk_burst(jip, jjkParam, jt));
        else if (jjkFx == 7) fx = jjk_vortex(jip, jjkParam, jt);
        else if (jjkFx >= 4) fx = jjk_orb_blue(jip64, jjkParam, jt);
        else fx = jjk_orb(jip64, jjkParam, jt);
        if (fx.a < 0.02) {
            discard;
        }
        #ifdef OIT_ALPHA_ONLY
        executeAlphaOnlyPhase(gl_FragCoord.z, fx.a);
        #elif defined(OIT_ACCUMULATE)
        fragColor = sampleColorForAccumulation(fx);
        #else
        fragColor = fx;
        #endif
        return;
    }
    vec4 color = texture(Sampler0, texCoord0);
    #ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
    #endif

    color *= vertexColor * ColorModulator;

    #ifdef GLINT
    color.a = max(color.a, GlintAlpha);
    #endif

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
