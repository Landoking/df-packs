#ifndef HAUNTLINE_COMMON_GLSL
#define HAUNTLINE_COMMON_GLSL
// Shared helpers for hauntline post effects. Include AFTER <minecraft:globals.glsl> (uses GameTime, ScreenSize).

float hl_seconds() {
    return GameTime * 1200.0;            // wraps every 20 minutes: only use through fract/sin/hash
}

float hl_hash(vec2 p) {
    return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

float hl_luma(vec3 c) {
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

// 1 in the middle, falling off toward the corners
float hl_vignette(vec2 uv, float strength) {
    float d = length((uv - 0.5) * vec2(1.0, 0.85)) * 1.41;
    return clamp(1.0 - strength * pow(d, 2.2), 0.0, 1.0);
}

// film grain, new pattern ~24 times a second
float hl_grain(vec2 uv) {
    float frame = floor(fract(hl_seconds() / 60.0) * 60.0 * 24.0);
    return hl_hash(uv * ScreenSize + vec2(frame * 1.7, frame * 3.1)) - 0.5;
}

// depth buffer value -> distance in blocks. 26.3 uses reversed-Z with an infinite far plane (checked with
// hauntline:depthdebug on 2026-11-18: sky = 0, near things -> larger values), so distance = near / depth.
float hl_linear_depth(float d) {
    const float n = 0.05;
    return n / max(d, 1e-7);
}

bool hl_is_sky(float d) {
    return d <= 1e-7;
}

#endif
