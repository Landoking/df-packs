#version 330
#extension GL_ARB_separate_shader_objects : require
// hauntline:dark - investigation grade: darker, colder, crushed shadows, vignette, light grain.
// Lit areas (flashlights, lamps) stay readable because the curve only crushes the low end.

#include <minecraft:globals.glsl>
#include <hauntline:common.glsl>

uniform sampler2D InSampler;

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

void main() {
    vec3 c = texture(InSampler, texCoord).rgb;
    c = pow(c, vec3(1.45)) * 0.9;
    c = mix(vec3(hl_luma(c)), c, 0.7);
    c *= vec3(0.9, 0.96, 1.1);
    c *= hl_vignette(texCoord, 0.6);
    c += hl_grain(texCoord) * 0.03;
    fragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
