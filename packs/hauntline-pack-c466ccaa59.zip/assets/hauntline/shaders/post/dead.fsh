#version 330
#extension GL_ARB_separate_shader_objects : require
// hauntline:dead - dead players spectating: cold, washed out, soft blur, faint breathing vignette.

#include <minecraft:globals.glsl>
#include <hauntline:common.glsl>

uniform sampler2D InSampler;

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

void main() {
    vec2 px = 1.5 / ScreenSize;
    vec3 c = texture(InSampler, texCoord).rgb * 0.4;
    c += texture(InSampler, texCoord + vec2(px.x, 0.0)).rgb * 0.15;
    c += texture(InSampler, texCoord - vec2(px.x, 0.0)).rgb * 0.15;
    c += texture(InSampler, texCoord + vec2(0.0, px.y)).rgb * 0.15;
    c += texture(InSampler, texCoord - vec2(0.0, px.y)).rgb * 0.15;
    float l = hl_luma(c);
    c = mix(vec3(l), c, 0.15) * vec3(0.8, 0.92, 1.15);
    c = mix(vec3(0.12, 0.14, 0.18), c, 0.8);                 // lift blacks, lower contrast
    float breathe = 0.85 + 0.15 * sin(hl_seconds() * 1.2);
    c *= hl_vignette(texCoord, 0.8 * breathe);
    fragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
