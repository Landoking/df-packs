#version 330
#extension GL_ARB_separate_shader_objects : require
// hauntline:hunt - while the ghost hunts: red pulse, chromatic split, random light dropouts, heavy vignette.

#include <minecraft:globals.glsl>
#include <hauntline:common.glsl>

uniform sampler2D InSampler;

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

void main() {
    float t = hl_seconds();
    float pulse = 0.5 + 0.5 * sin(t * 6.2831853 * 1.3);
    float n = hl_hash(vec2(floor(t * 8.0), 3.1));
    float dim = n < 0.2 ? 0.2 : 1.0;                       // flashlights cut out now and then
    vec2 off = (texCoord - 0.5) * 0.007 * (0.6 + pulse);
    vec3 c = vec3(texture(InSampler, texCoord + off).r,
                  texture(InSampler, texCoord).g,
                  texture(InSampler, texCoord - off).b);
    c = mix(c, c * vec3(1.3, 0.5, 0.5), 0.45 + 0.25 * pulse);
    c *= dim * hl_vignette(texCoord, 0.95);
    c += hl_grain(texCoord) * 0.06;
    fragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
