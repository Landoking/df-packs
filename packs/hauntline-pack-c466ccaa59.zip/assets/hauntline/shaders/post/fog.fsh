#version 330
#extension GL_ARB_separate_shader_objects : require
// hauntline:fog - thick distance fog from the depth buffer (outside / spooky maps). Sky becomes fog.

#include <minecraft:globals.glsl>
#include <hauntline:common.glsl>

uniform sampler2D InSampler;
uniform sampler2D DepthSampler;

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

void main() {
    vec3 c = texture(InSampler, texCoord).rgb;
    float d = texture(DepthSampler, texCoord).r;
    float z = hl_linear_depth(d);
    float f = 1.0 - exp(-pow(z * 0.1, 1.5));              // ~50% at 8 blocks, ~85% at 15
    // slow drifting density so the fog breathes a little
    float drift = 0.06 * sin(hl_seconds() * 0.4 + texCoord.x * 6.0 + texCoord.y * 3.0);
    f = hl_is_sky(d) ? 0.93 : clamp(f + drift * f, 0.0, 0.93);
    vec3 fogCol = vec3(0.085, 0.095, 0.115);
    c = mix(c, fogCol, f);
    c += hl_grain(texCoord) * 0.02;
    fragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
