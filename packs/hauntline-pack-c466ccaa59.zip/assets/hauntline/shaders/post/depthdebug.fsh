#version 330
#extension GL_ARB_separate_shader_objects : require
// hauntline:depthdebug - dev only: distance in blocks as grey (white = 32+ blocks), sky red.

#include <minecraft:globals.glsl>
#include <hauntline:common.glsl>

uniform sampler2D InSampler;
uniform sampler2D DepthSampler;

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

void main() {
    float d = texture(DepthSampler, texCoord).r;
    if (hl_is_sky(d)) {
        fragColor = vec4(0.6, 0.0, 0.0, 1.0);
        return;
    }
    float v = clamp(hl_linear_depth(d) / 32.0, 0.0, 1.0);
    fragColor = vec4(v, v, v, 1.0);
}
