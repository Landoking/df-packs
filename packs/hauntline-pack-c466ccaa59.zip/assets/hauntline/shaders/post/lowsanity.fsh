#version 330
#extension GL_ARB_separate_shader_objects : require
// hauntline:lowsanity - sanity under 25%: the room wobbles, colours split at the edges, vignette breathes.

#include <minecraft:globals.glsl>
#include <hauntline:common.glsl>

uniform sampler2D InSampler;

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

void main() {
    float t = hl_seconds();
    vec2 uv = texCoord;
    uv.x += sin(uv.y * 18.0 + t * 1.7) * 0.0022;
    uv.y += cos(uv.x * 14.0 + t * 1.3) * 0.0016;
    float edge = length(texCoord - 0.5);
    vec2 off = (texCoord - 0.5) * 0.01 * edge;
    vec3 c = vec3(texture(InSampler, uv + off).r, texture(InSampler, uv).g, texture(InSampler, uv - off).b);
    c *= hl_vignette(texCoord, 0.7 + 0.2 * sin(t * 0.9));
    fragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
