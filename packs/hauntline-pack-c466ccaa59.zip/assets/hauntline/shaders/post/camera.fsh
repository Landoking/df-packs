#version 330
#extension GL_ARB_separate_shader_objects : require
// hauntline:camera - looking through a placed video camera: green night vision, barrel lens, scanlines,
// rolling bar, noise, blinking REC dot top-left.

#include <minecraft:globals.glsl>
#include <hauntline:common.glsl>

uniform sampler2D InSampler;

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

void main() {
    float t = hl_seconds();
    vec2 p = texCoord - 0.5;
    vec2 uv = 0.5 + p * (1.0 + 0.12 * dot(p, p));          // barrel distortion
    if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) {
        fragColor = vec4(0.0, 0.0, 0.0, 1.0);
        return;
    }
    float l = hl_luma(texture(InSampler, uv).rgb);
    l = clamp(pow(l, 0.55) * 1.35, 0.0, 1.0);                // night-vision gain
    vec3 c = vec3(0.3, 1.0, 0.4) * l;
    c *= 0.86 + 0.14 * sin(uv.y * ScreenSize.y * 1.6);       // scanlines
    float bar = fract(uv.y + t * 0.12);
    c *= 0.9 + 0.1 * smoothstep(0.0, 0.08, abs(bar - 0.5));  // rolling bar
    c += hl_grain(uv) * 0.12;
    c *= hl_vignette(uv, 1.1);
    // REC dot
    vec2 a = vec2(ScreenSize.x / ScreenSize.y, 1.0);
    if (fract(t) < 0.6 && length((texCoord - vec2(0.05, 0.93)) * a) < 0.014) {
        c = vec3(0.95, 0.1, 0.1);
    }
    fragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}
